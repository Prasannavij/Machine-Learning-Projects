import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import numpy as np
import cv2
import math

# Import from our new modules
from constants import *
import file_handler
import drawing_utils
from ui_manager import UIManager

class FloorplanGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Room Floorplan Generator")
        self.root.geometry("1100x850")

        # --- State Variables ---
        self.current_floorplan_data = None 
        self.save_counter = 1
        self.scratch_points = []
        self.is_scratch_closed = False
        self.doors_on_plan = []
        self.windows_on_plan = []
        self.wall_definitions = {}
        self.current_canvas_image = None
        self.tk_image = None
        self.zoom_level = 1.0

        self.shapes = file_handler.load_json("room_shapes.json", "Room Shapes")
        self.door_types = file_handler.load_json("doors.json", "Door Types")
        self.window_types = file_handler.load_json("windows.json", "Window Types")
        
        self.ui = UIManager(self)
        self.ui.setup_ui()
        
        self.reset_application()

    def zoom_in(self):
        self.zoom_level = min(self.zoom_level * 1.25, 8.0)
        self.redraw_canvas()

    def zoom_out(self):
        self.zoom_level = max(self.zoom_level / 1.25, 0.2)
        self.redraw_canvas()

    def add_door_to_plan(self, wall_var, pos_entry, type_var, hinge_var, swing_var, width_var):
        if not self.current_floorplan_data: return
        try:
            wall_label = wall_var.get()
            if not wall_label: messagebox.showerror("Error", "Please select a wall."); return
            position = float(pos_entry.get())
            door_type_name = type_var.get()
            door_info = self.door_types[door_type_name]
            custom_width_str = width_var.get()
            door_width = float(custom_width_str) if custom_width_str else door_info["width"]
            p1 = self.wall_definitions[wall_label]["p1"]; p2 = self.wall_definitions[wall_label]["p2"]
            wall_length = math.hypot(p2[0] - p1[0], p2[1] - p1[1])
            if position + door_width > wall_length: messagebox.showerror("Error", f"Door does not fit."); return
        except Exception as e: messagebox.showerror("Invalid Input", f"Please check door parameters.\nError: {e}"); return
        all_openings = self.doors_on_plan + self.windows_on_plan
        openings_on_same_wall = sorted([o for o in all_openings if o["wall_label"] == wall_label], key=lambda x: x['position'])
        final_position = position
        is_position_valid = False
        while not is_position_valid:
            is_position_valid = True; new_start = final_position; new_end = final_position + door_width
            for opening in openings_on_same_wall:
                existing_start = opening["position"]; existing_end = opening["position"] + opening["width"]
                if new_start < existing_end and existing_start < new_end:
                    final_position = existing_end + 1.0; is_position_valid = False; break
        if final_position + door_width > wall_length: messagebox.showerror("No Space Available", "Could not find a free space for this door."); return
        if final_position != position:
            if not messagebox.askyesno("Position Occupied", f"Position is occupied.\nPlace door at next available spot ({final_position:.0f} cm)?"): return
        door_data = {"wall_label": wall_label, "position": final_position, "width": door_width, "type": door_type_name, "hinge": hinge_var.get(), "swing": swing_var.get(), "color_bgr": door_info["color_bgr"], "draw_style": door_info.get("draw_style", "Swinging")}
        self.doors_on_plan.append(door_data); self.redraw_canvas()

    def add_window_to_plan(self, wall_var, pos_entry, type_var, width_var):
        if not self.current_floorplan_data: return
        try:
            wall_label = wall_var.get()
            if not wall_label: messagebox.showerror("Error", "Please select a wall."); return
            position = float(pos_entry.get())
            win_type_name = type_var.get()
            win_info = self.window_types[win_type_name]
            custom_width_str = width_var.get()
            win_width = float(custom_width_str) if custom_width_str else win_info["width"]
            p1 = self.wall_definitions[wall_label]["p1"]; p2 = self.wall_definitions[wall_label]["p2"]
            wall_length = math.hypot(p2[0] - p1[0], p2[1] - p1[1])
            if position + win_width > wall_length: messagebox.showerror("Error", f"Window does not fit."); return
        except Exception as e: messagebox.showerror("Invalid Input", f"Please check window parameters.\nError: {e}"); return
        all_openings = self.doors_on_plan + self.windows_on_plan
        openings_on_same_wall = sorted([o for o in all_openings if o["wall_label"] == wall_label], key=lambda x: x['position'])
        new_start = position; new_end = position + win_width
        for opening in openings_on_same_wall:
            existing_start = opening["position"]; existing_end = opening["position"] + opening["width"]
            if new_start < existing_end and existing_start < new_end:
                messagebox.showerror("Position Occupied", "The selected position overlaps with an existing door or window."); return
        window_data = {"wall_label": wall_label, "position": position, "width": win_width, "type": win_type_name, "color_bgr": win_info["color_bgr"], "draw_style": win_info.get("draw_style", "Standard")}
        self.windows_on_plan.append(window_data); self.redraw_canvas()

    def redraw_canvas(self):
        if not self.current_floorplan_data: return
        data_type = self.current_floorplan_data["type"]
        if data_type == 'scratch': self.redraw_scratch_canvas()
        elif data_type == 'template': self.draw_template_shape(redraw_only=True)
        elif data_type == 'custom_rectangle': self.draw_custom_room(redraw_only=True)
            
    def identify_walls(self, coords):
        self.wall_definitions = {}; counts = {"North": 0, "South": 0, "East": 0, "West": 0, "Angled": 0}
        if len(coords) < 2: return []
        center_x = np.mean([p[0] for p in coords]); center_y = np.mean([p[1] for p in coords])
        is_closed = self.is_scratch_closed or self.current_floorplan_data['type'] != 'scratch'
        num_segments = len(coords) if is_closed else len(coords) - 1
        for i in range(num_segments):
            p1 = coords[i]; p2 = coords[(i + 1) % len(coords)]; mid_x = (p1[0] + p2[0]) / 2; mid_y = (p1[1] + p2[1]) / 2
            dx = p2[0] - p1[0]; dy = p2[1] - p1[1]; label = ""; tolerance = 1e-9
            if abs(dx) > abs(dy) + tolerance: label = "North" if mid_y < center_y else "South"
            elif abs(dy) > abs(dx) + tolerance: label = "East" if mid_x > center_x else "West"
            else: label = "Angled"
            counts[label] += 1; wall_label = f"{label} Wall {counts[label]}"; self.wall_definitions[wall_label] = {"p1": p1, "p2": p2}
        return list(self.wall_definitions.keys())

    def set_placement_controls_state(self, controls_list, state="normal"):
        for controls in controls_list:
            for widget in controls.values():
                if 'state' in widget.keys(): widget.config(state=state)
        if state == "normal" and self.current_floorplan_data:
            coords = self.current_floorplan_data.get("coordinates", [])
            wall_labels = self.identify_walls(coords)
            for controls in controls_list:
                controls["wall_combo"]["values"] = wall_labels
                if wall_labels: controls["wall_combo"].current(0)
    
    def draw_template_shape(self, redraw_only=False):
        if not redraw_only:
            try: thickness = float(self.template_thickness_entry.get())
            except (ValueError, TypeError): messagebox.showerror("Invalid Input", "Please enter a valid thickness."); return
            selected_shape_name = self.shape_var.get(); shape_data = self.shapes.get(selected_shape_name)
            if not shape_data or "coordinates" not in shape_data: return
            self.current_floorplan_data = {"type": "template", "name": selected_shape_name, "coordinates": shape_data["coordinates"], "wall_thickness": thickness}
            self.doors_on_plan = []; self.windows_on_plan = []; self.save_template_btn.config(state="normal")
            self.set_placement_controls_state([self.template_door_controls, self.template_window_controls], "normal")
            self.set_placement_controls_state([self.custom_door_controls, self.custom_window_controls, self.scratch_door_controls, self.scratch_window_controls], "disabled")

        coords = self.current_floorplan_data["coordinates"]; thickness = self.current_floorplan_data["wall_thickness"]
        min_x, min_y = np.min(coords, axis=0); max_x, max_y = np.max(coords, axis=0)
        shape_width = max(1, max_x - min_x); shape_height = max(1, max_y - min_y)
        total_width = shape_width + 2 * thickness; total_height = shape_height + 2 * thickness
        scale = min((self.canvas.winfo_width() - 2 * CANVAS_PADDING) / total_width, (self.canvas.winfo_height() - 2 * CANVAS_PADDING) / total_height) * self.zoom_level
        offset_x = (self.canvas.winfo_width() - shape_width * scale) / 2 - min_x * scale
        offset_y = (self.canvas.winfo_height() - shape_height * scale) / 2 - min_y * scale
        final_coords = [(p[0] * scale + offset_x, p[1] * scale + offset_y) for p in coords]
        
        img = np.ones((self.canvas.winfo_height(), self.canvas.winfo_width(), 3), dtype=np.uint8) * 255
        final_coords_np = np.array(final_coords, dtype=np.int32)
        scaled_thickness = max(2, int(thickness * scale))
        cv2.polylines(img, [final_coords_np], isClosed=True, color=(50,50,50), thickness=scaled_thickness)
        cv2.fillPoly(img, [final_coords_np], color=(235, 245, 255))
        
        drawing_utils.add_measurement_text(img, coords, final_coords, True)
        drawing_utils.draw_windows(img, scale, offset_x, offset_y, self)
        drawing_utils.draw_doors(img, scale, offset_x, offset_y, self)
        self.display_image_on_canvas(img)
        
    def draw_custom_room(self, redraw_only=False):
        if not redraw_only:
            try: width = float(self.width_entry.get()); height = float(self.height_entry.get()); thickness = float(self.thickness_entry.get())
            except ValueError: return
            self.current_floorplan_data = {"type": "custom_rectangle", "inner_width": width, "inner_height": height, "wall_thickness": thickness}
            self.current_floorplan_data["coordinates"] = [[0,0], [width, 0], [width, height], [0, height]]
            self.doors_on_plan = []; self.windows_on_plan = []; self.save_custom_btn.config(state="normal")
            self.set_placement_controls_state([self.custom_door_controls, self.custom_window_controls], "normal")
            self.set_placement_controls_state([self.template_door_controls, self.template_window_controls, self.scratch_door_controls, self.scratch_window_controls], "disabled")

        width = self.current_floorplan_data["inner_width"]; height = self.current_floorplan_data["inner_height"]; thickness = self.current_floorplan_data["wall_thickness"]
        total_width = width + 2*thickness; total_height = height + 2*thickness
        scale = min((self.canvas.winfo_width() - 2 * CANVAS_PADDING) / total_width, (self.canvas.winfo_height() - 2 * CANVAS_PADDING) / total_height) * self.zoom_level
        s_total_w = int(total_width * scale); s_total_h = int(total_height * scale); s_thick = int(thickness * scale)
        offset_x = (self.canvas.winfo_width() - s_total_w) // 2; offset_y = (self.canvas.winfo_height() - s_total_h) // 2
        p1_outer, p2_outer = (offset_x, offset_y), (offset_x + s_total_w, offset_y + s_total_h)
        img = np.ones((self.canvas.winfo_height(), self.canvas.winfo_width(), 3), dtype=np.uint8) * 255
        cv2.rectangle(img, p1_outer, p2_outer, color=(50, 50, 50), thickness=cv2.FILLED)
        p1_inner = (p1_outer[0] + s_thick, p1_outer[1] + s_thick); p2_inner = (p2_outer[0] - s_thick, p2_outer[1] - s_thick)
        cv2.rectangle(img, p1_inner, p2_inner, color=(255, 255, 255), thickness=cv2.FILLED)
        
        width_text = f"{width:.0f}"; w_text_size, _ = cv2.getTextSize(width_text, FONT, FONT_SCALE, FONT_THICKNESS)
        w_pos = ((p1_inner[0] + p2_inner[0]) // 2 - w_text_size[0] // 2, p1_inner[1] + w_text_size[0] + 15)
        cv2.putText(img, width_text, w_pos, FONT, FONT_SCALE, FONT_COLOR_RED, FONT_THICKNESS)
        height_text = f"{height:.0f}"; h_text_size, _ = cv2.getTextSize(height_text, FONT, FONT_SCALE, FONT_THICKNESS)
        h_pos = (p1_inner[0] + 15, (p1_inner[1] + p2_inner[1]) // 2 + h_text_size[1] // 2)
        cv2.putText(img, height_text, h_pos, FONT, FONT_SCALE, FONT_COLOR_RED, FONT_THICKNESS)

        drawing_utils.draw_windows(img, scale, p1_inner[0], p1_inner[1], self)
        drawing_utils.draw_doors(img, scale, p1_inner[0], p1_inner[1], self)
        self.display_image_on_canvas(img)

    def redraw_scratch_canvas(self):
        if not self.scratch_points or not self.current_floorplan_data: return
        coords = self.current_floorplan_data["coordinates"]; thickness = self.current_floorplan_data["wall_thickness"]
        min_x, min_y = np.min(coords, axis=0); max_x, max_y = np.max(coords, axis=0)
        shape_width = max(1, max_x-min_x); shape_height = max(1, max_y-min_y)
        
        # --- MODIFIED: Include thickness in total dimension for scaling ---
        total_width = shape_width + 2 * thickness
        total_height = shape_height + 2 * thickness
        scale = min((self.canvas.winfo_width() - 2 * CANVAS_PADDING) / total_width, (self.canvas.winfo_height() - 2 * CANVAS_PADDING) / total_height) * self.zoom_level
        
        offset_x = (self.canvas.winfo_width() - shape_width*scale)/2 - min_x*scale
        offset_y = (self.canvas.winfo_height() - shape_height*scale)/2 - min_y*scale
        final_coords = [(p[0]*scale + offset_x, p[1]*scale + offset_y) for p in coords]
        img = np.ones((self.canvas.winfo_height(), self.canvas.winfo_width(), 3), dtype=np.uint8) * 255
        
        final_coords_np = np.array(final_coords, dtype=np.int32)
        scaled_thickness = max(2, int(thickness * scale))
        
        if self.is_scratch_closed:
            cv2.polylines(img, [final_coords_np], isClosed=True, color=(50,50,50), thickness=scaled_thickness)
            cv2.fillPoly(img, [final_coords_np], color=(235, 245, 255))
        else:
            # --- FIXED: Use scaled_thickness for open shapes too ---
            cv2.polylines(img, [final_coords_np], isClosed=False, color=(50,50,50), thickness=scaled_thickness)
            if len(final_coords) > 0:
                cv2.circle(img, tuple(np.int32(final_coords[0])), 5, (0, 128, 0), -1); cv2.circle(img, tuple(np.int32(final_coords[-1])), 5, (0, 0, 255), -1)
        
        drawing_utils.add_measurement_text(img, coords, final_coords, self.is_scratch_closed)
        drawing_utils.draw_windows(img, scale, offset_x, offset_y, self)
        drawing_utils.draw_doors(img, scale, offset_x, offset_y, self)
        self.display_image_on_canvas(img)
    
    def close_scratch_shape(self):
        if len(self.scratch_points) < 3:
            messagebox.showwarning("Warning", "You need at least 3 points to create a closed shape.")
            return
        self.is_scratch_closed = True
        self.add_wall_btn.config(state="disabled")
        self.close_shape_btn.config(state="disabled")
        self.current_floorplan_data['wall_thickness'] = float(self.scratch_thickness_entry.get() or 20)
        self.current_floorplan_data['wall_height'] = float(self.scratch_height_entry.get() or 250)
        # Do NOT reset doors/windows here!
        # self.doors_on_plan = []
        # self.windows_on_plan = []
        self.redraw_canvas()
        self.save_scratch_btn.config(state="normal")
        self.set_placement_controls_state([self.scratch_door_controls, self.scratch_window_controls], "normal")
        self.set_placement_controls_state([self.template_door_controls, self.template_window_controls, self.custom_door_controls, self.custom_window_controls], "disabled")

    def reset_application(self):
        self.scratch_points = [[0, 0]]; self.is_scratch_closed = False; self.current_floorplan_data = None; self.doors_on_plan = []; self.windows_on_plan = []
        self.zoom_level = 1.0
        
        if hasattr(self, 'add_wall_btn'):
            self.add_wall_btn.config(state="normal"); self.close_shape_btn.config(state="normal"); self.save_scratch_btn.config(state="disabled")
            self.scratch_status_label.config(text="Start Point: (0, 0)")
        
        self.set_placement_controls_state([self.scratch_door_controls, self.scratch_window_controls,
                                           self.template_door_controls, self.template_window_controls,
                                           self.custom_door_controls, self.custom_window_controls], "disabled")
        if hasattr(self, 'save_template_btn'): self.save_template_btn.config(state="disabled")
        if hasattr(self, 'save_custom_btn'): self.save_custom_btn.config(state="disabled")
        
        self.canvas.delete("all")
        self.current_canvas_image = None
        self.root.update_idletasks()
        img = np.ones((self.canvas.winfo_height(), self.canvas.winfo_width(), 3), dtype=np.uint8) * 255
        if self.canvas.winfo_height() > 1 and self.canvas.winfo_width() > 1:
            cv2.putText(img, "Select an option on the left to begin.", (50, self.canvas.winfo_height() // 2), FONT, 0.7, (128,128,128), 1)
        self.display_image_on_canvas(img)
        if hasattr(self, 'notebook'): self.notebook.select(self.tab_template)

    def add_scratch_wall(self):
        try: length = float(self.scratch_length_entry.get())
        except (ValueError, TypeError): messagebox.showerror("Invalid Input", "Please enter a positive number for the wall length."); return
        direction=self.scratch_direction_var.get(); last_point=self.scratch_points[-1]; dx,dy=0,0
        if direction == "Right (East)": dx=length
        elif direction == "Up (North)": dy=-length
        elif direction == "Left (West)": dx=-length
        elif direction == "Down (South)": dy=length
        new_point = [last_point[0]+dx, last_point[1]+dy]
        self.scratch_points.append(new_point); self.scratch_status_label.config(text=f"Current Point: ({new_point[0]:.1f}, {new_point[1]:.1f})")
        self.current_floorplan_data = {"type": "scratch", "coordinates": self.scratch_points, "wall_thickness": float(self.scratch_thickness_entry.get() or 20)}
        
        # --- NEW: Enable placement controls as soon as there's a wall ---
        if len(self.scratch_points) > 1:
            self.set_placement_controls_state([self.scratch_door_controls, self.scratch_window_controls], "normal")

        self.redraw_canvas()
        
    def save_floorplan(self):
        file_handler.save_floorplan(self)

    def display_image_on_canvas(self, cv2_img):
        self.current_canvas_image = cv2_img
        rgb_img = cv2.cvtColor(cv2_img, cv2.COLOR_BGR2RGB); pil_img = Image.fromarray(rgb_img)
        self.tk_image = ImageTk.PhotoImage(image=pil_img)
        self.canvas.delete("all"); self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_image)

if __name__ == "__main__":
    root = tk.Tk()
    app = FloorplanGeneratorApp(root)
    root.mainloop()