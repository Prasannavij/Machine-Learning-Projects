import cv2

# --- Constants ---
CANVAS_WIDTH = 700
CANVAS_HEIGHT = 650
CANVAS_PADDING = 50
FONT = cv2.FONT_HERSHEY_SIMPLEX
FONT_SCALE = 0.5
FONT_COLOR_RED = (0, 0, 255) # BGR format for red
FONT_THICKNESS = 1
WINDOW_COLOR = (255, 150, 0) # Light Blue for window symbols