import json
import os
import cv2
import numpy as np
import math
from tkinter import messagebox, filedialog

def load_json(filename, file_description):
    """Loads a JSON file and returns its content."""
    try:
        with open(filename, "r") as f:
            return json.load(f)
    except Exception as e:
        messagebox.showerror("Error", f"Could not load {file_description} from {filename}:\n{e}")
        return {}

def save_floorplan(app):
    """
    Saves the current floorplan data as a JSON file and a PNG image.
    Enriches door and window data with absolute coordinates before saving.
    """
    if app.current_floorplan_data is None or app.current_canvas_image is None: 
        messagebox.showwarning("No Data", "There is no floorplan on the canvas to save.")
        return
        
    data_to_save = app.current_floorplan_data.copy()

    # Enrich door data
    enriched_doors = []
    for door in app.doors_on_plan:
        enriched_door = door.copy()
        wall = app.wall_definitions.get(door["wall_label"])
        if wall:
            p1 = np.array(wall["p1"]); p2 = np.array(wall["p2"])
            wall_vec = p2 - p1; wall_len = np.linalg.norm(wall_vec)
            if wall_len > 0:
                wall_unit_vec = wall_vec / wall_len
                door_start_pt = p1 + wall_unit_vec * door["position"]
                door_end_pt = door_start_pt + wall_unit_vec * door["width"]
                enriched_door["absolute_coordinates"] = {
                    "start_point": [round(c, 2) for c in door_start_pt],
                    "end_point": [round(c, 2) for c in door_end_pt]
                }
        enriched_doors.append(enriched_door)
    data_to_save['doors'] = enriched_doors

    # Enrich window data
    enriched_windows = []
    for window in app.windows_on_plan:
        enriched_window = window.copy()
        wall = app.wall_definitions.get(window["wall_label"])
        if wall:
            p1 = np.array(wall["p1"]); p2 = np.array(wall["p2"])
            wall_vec = p2 - p1; wall_len = np.linalg.norm(wall_vec)
            if wall_len > 0:
                wall_unit_vec = wall_vec / wall_len
                window_start_pt = p1 + wall_unit_vec * window["position"]
                window_end_pt = window_start_pt + wall_unit_vec * window["width"]
                enriched_window["absolute_coordinates"] = {
                    "start_point": [round(c, 2) for c in window_start_pt],
                    "end_point": [round(c, 2) for c in window_end_pt]
                }
        enriched_windows.append(enriched_window)
    data_to_save['windows'] = enriched_windows
    
    initial_filename = f"floorplan_{app.save_counter}"
    filepath = filedialog.asksaveasfilename(initialfile=f"{initial_filename}.json", defaultextension=".json", filetypes=[("JSON Files", "*.json")])
    if not filepath: return
    
    json_path = filepath
    image_path = f"{os.path.splitext(json_path)[0]}.png"

    try:
        with open(json_path, "w") as f: 
            json.dump(data_to_save, f, indent=4)
        cv2.imwrite(image_path, app.current_canvas_image)
        messagebox.showinfo("Success", f"Saved successfully!\nJSON: {os.path.basename(json_path)}\nImage: {os.path.basename(image_path)}")
        app.save_counter += 1
    except Exception as e: 
        messagebox.showerror("Save Error", f"An error occurred while saving the files:\n{e}")