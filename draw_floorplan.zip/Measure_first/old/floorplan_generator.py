import tkinter as tk
from tkinter import messagebox
import cv2
import numpy as np

def generate_floorplan_with_walls():
    
    try:
        room_height_cm = int(height3d_entry.get())
        width_cm = int(width_entry.get())
        height_cm = int(height_entry.get())
        wall_cm = int(wall_entry.get())

        scale = 5  # 1 cm = 5 pixels
        width_px = width_cm * scale
        height_px = height_cm * scale
        wall_px = wall_cm * scale

        padding = 100
        canvas_w = width_px + padding * 2
        canvas_h = height_px + padding * 2
        image = np.ones((canvas_h, canvas_w, 3), dtype=np.uint8) * 255

        outer_top_left = (padding, padding)
        outer_bottom_right = (padding + width_px, padding + height_px)

        inner_top_left = (padding + wall_px, padding + wall_px)
        inner_bottom_right = (padding + width_px - wall_px, padding + height_px - wall_px)

        # Draw black outer wall
        cv2.rectangle(image, outer_top_left, outer_bottom_right, (0, 0, 0), -1)

        # Fill white inner area
        cv2.rectangle(image, inner_top_left, inner_bottom_right, (255, 255, 255), -1)

        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 1
        thickness = 2

        # Width text
        cv2.putText(image, f"{width_cm} cm", 
                    (padding + width_px // 2 - 50, padding - 20), 
                    font, font_scale, (0, 0, 255), thickness)

        # Height text
        cv2.putText(image, f"{height_cm} cm", 
                    (padding - 90, padding + height_px // 2), 
                    font, font_scale, (0, 0, 255), thickness)
        
        cv2.putText(image, f"Wall Height: {room_height_cm} cm", 
            (padding, padding + height_px + 50), 
            font, font_scale, (255, 0, 0), thickness)


        output_path = "room_with_walls.png"
        cv2.imwrite(output_path, image)
        messagebox.showinfo("Success", f"Floorplan saved as {output_path}")

    except ValueError:
        messagebox.showerror("Input Error", "Please enter valid numeric values.")

# Tkinter UI
root = tk.Tk()
root.title("Room Floorplan Generator (With Wall Thickness)")

tk.Label(root, text="Room Width (cm):").grid(row=0, column=0, sticky="e", padx=10, pady=5)
tk.Label(root, text="Room Height (cm):").grid(row=1, column=0, sticky="e", padx=10, pady=5)
tk.Label(root, text="Wall Height (cm):").grid(row=3, column=0, sticky="e", padx=10, pady=5)
height3d_entry = tk.Entry(root)
height3d_entry.grid(row=3, column=1, padx=10, pady=5)
tk.Label(root, text="Wall Thickness (cm):").grid(row=2, column=0, sticky="e", padx=10, pady=5)

width_entry = tk.Entry(root)
height_entry = tk.Entry(root)
wall_entry = tk.Entry(root)

width_entry.grid(row=0, column=1, padx=10, pady=5)
height_entry.grid(row=1, column=1, padx=10, pady=5)
wall_entry.grid(row=2, column=1, padx=10, pady=5)

generate_btn = tk.Button(root, text="Generate Floorplan", command=generate_floorplan_with_walls)
generate_btn.grid(row=4, column=0, columnspan=2, pady=15)


root.mainloop()
