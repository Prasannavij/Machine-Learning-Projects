import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import numpy as np
import cv2


# Constants
SCALE = 10  # pixels per cm

def draw_room(width_cm, height_cm, thickness_cm):
    # Convert to pixels
    width_px = int(width_cm * SCALE)
    height_px = int(height_cm * SCALE)
    thickness_px = int(thickness_cm * SCALE)

    img = np.ones((height_px + 100, width_px + 100, 3), dtype=np.uint8) * 255

    # Coordinates
    x1 = 50
    y1 = 50
    x2 = x1 + width_px
    y2 = y1 + height_px

    # Draw outer wall
    cv2.rectangle(img, (x1, y1), (x2, y2), (0, 0, 0), thickness=thickness_px)

    return img


class RoomDesignerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Room Drawing Tool")

        # Layout
        self.root.geometry("900x600")
        self.root.resizable(False, False)

        # Left frame - Inputs
        self.left_frame = tk.Frame(self.root, width=300)
        self.left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)

        # Right frame - Canvas/Image display
        self.right_frame = tk.Frame(self.root, width=600, height=600)
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.setup_inputs()
        self.setup_canvas()

    def setup_inputs(self):
        tk.Label(self.left_frame, text="Room Width (cm)").pack(pady=(10, 0))
        self.width_entry = ttk.Entry(self.left_frame)
        self.width_entry.insert(0, "300")
        self.width_entry.pack()

        tk.Label(self.left_frame, text="Room Height (cm)").pack(pady=(10, 0))
        self.height_entry = ttk.Entry(self.left_frame)
        self.height_entry.insert(0, "400")
        self.height_entry.pack()

        tk.Label(self.left_frame, text="Wall Thickness (cm)").pack(pady=(10, 0))
        self.thickness_entry = ttk.Entry(self.left_frame)
        self.thickness_entry.insert(0, "20")
        self.thickness_entry.pack()

        self.draw_button = ttk.Button(self.left_frame, text="Draw Room", command=self.update_image)
        self.draw_button.pack(pady=20)

    def setup_canvas(self):
        self.canvas = tk.Canvas(self.right_frame, bg="white")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.tk_image = None

    def update_image(self):
        try:
            width = float(self.width_entry.get())
            height = float(self.height_entry.get())
            thickness = float(self.thickness_entry.get())
        except ValueError:
            print("Invalid input")
            return

        img = draw_room(width, height, thickness)

        # Resize image to fit canvas
        max_canvas_size = 600
        img_h, img_w = img.shape[:2]
        scale_ratio = min(max_canvas_size / img_w, max_canvas_size / img_h)

        resized_img = cv2.resize(img, None, fx=scale_ratio, fy=scale_ratio, interpolation=cv2.INTER_AREA)

        # Convert to Tkinter image
        bgr_image = cv2.cvtColor(resized_img, cv2.COLOR_BGR2RGB)
        pil_image = Image.fromarray(bgr_image)
        self.tk_image = ImageTk.PhotoImage(pil_image)

        # Clear and display
        self.canvas.delete("all")
        self.canvas.config(width=resized_img.shape[1], height=resized_img.shape[0])
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_image)


# Main execution
if __name__ == "__main__":
    root = tk.Tk()
    app = RoomDesignerApp(root)
    root.mainloop()
