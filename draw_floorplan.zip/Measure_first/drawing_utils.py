import cv2
import numpy as np
import math
from constants import *

def draw_dashed_ellipse(img, center, axes, angle, start_angle, end_angle, color, thickness=1):
    center_int = tuple(np.int32(center)); axes_int = tuple(np.int32(axes))
    pts = cv2.ellipse2Poly(center_int, axes_int, angle, start_angle, end_angle, 5)
    for i in range(0, len(pts) - 1, 2):
        p1 = tuple(pts[i]); p2 = tuple(pts[i+1])
        cv2.line(img, p1, p2, color, thickness)

def add_measurement_text(img, coords, final_coords, is_closed):
    if len(coords) < 2: return
    num_segments = len(coords) if is_closed else len(coords) - 1
    for i in range(num_segments):
        p1_orig, p2_orig = coords[i], coords[(i + 1) % len(coords)]
        p1_scaled, p2_scaled = final_coords[i], final_coords[(i + 1) % len(final_coords)]
        length = np.linalg.norm(np.array(p1_orig) - np.array(p2_orig))
        midpoint = ((p1_scaled[0] + p2_scaled[0]) / 2, (p1_scaled[1] + p2_scaled[1]) / 2)
        text = f"{length:.0f}"; text_size, _ = cv2.getTextSize(text, FONT, FONT_SCALE, FONT_THICKNESS)
        label_pos = list(midpoint)
        if abs(p1_scaled[0] - p2_scaled[0]) > abs(p1_scaled[1] - p2_scaled[1]):
            label_pos[0] -= text_size[0] / 2; label_pos[1] -= 20
        else:
            label_pos[0] -= text_size[0] + 20; label_pos[1] += text_size[1] / 2
        cv2.putText(img, text, (int(label_pos[0]), int(label_pos[1])), FONT, FONT_SCALE, FONT_COLOR_RED, FONT_THICKNESS)

def draw_windows(img, scale, offset_x, offset_y, app_data):
    if not app_data.windows_on_plan: return
    for window in app_data.windows_on_plan:
        wall = app_data.wall_definitions.get(window["wall_label"])
        if not wall: continue
        
        window_color = tuple(window.get("color_bgr", WINDOW_COLOR))
        p1 = np.array(wall["p1"]); p2 = np.array(wall["p2"])
        wall_vec = p2 - p1; wall_len = np.linalg.norm(wall_vec)
        if wall_len == 0: continue
        wall_unit_vec = wall_vec / wall_len
        wall_normal = np.array([-wall_unit_vec[1], wall_unit_vec[0]])
        
        win_start_pt = p1 + wall_unit_vec * window["position"]
        win_end_pt = win_start_pt + wall_unit_vec * window["width"]
        win_start_scaled = (win_start_pt[0] * scale + offset_x, win_start_pt[1] * scale + offset_y)
        win_end_scaled = (win_end_pt[0] * scale + offset_x, win_end_pt[1] * scale + offset_y)
        
        thickness = app_data.current_floorplan_data.get("wall_thickness", 20)
        scaled_thickness = max(3, int(thickness * scale))

        # 1. Create opening in the wall
        cv2.line(img, tuple(np.int32(win_start_scaled)), tuple(np.int32(win_end_scaled)), (255, 255, 255), scaled_thickness)
        
        # 2. Draw the window symbol (three parallel lines for standard)
        if window.get("draw_style") == "Standard":
            center_line_start = (np.array(win_start_scaled) + np.array(win_end_scaled)) / 2 - wall_normal * (scaled_thickness / 4)
            center_line_end = (np.array(win_start_scaled) + np.array(win_end_scaled)) / 2 + wall_normal * (scaled_thickness / 4)
            
            cv2.line(img, tuple(np.int32(win_start_scaled)), tuple(np.int32(win_end_scaled)), window_color, 1)
            cv2.line(img, tuple(np.int32(center_line_start)), tuple(np.int32(center_line_end)), window_color, 1)

def draw_doors(img, scale, offset_x, offset_y, app_data):
    if not app_data.doors_on_plan: return
    for door in app_data.doors_on_plan:
        # ... (This function is unchanged) ...
        wall = app_data.wall_definitions.get(door["wall_label"]); 
        if not wall: continue
        door_color = tuple(door.get("color_bgr", [150, 75, 0]))
        p1 = np.array(wall["p1"]); p2 = np.array(wall["p2"])
        wall_vec = p2 - p1; wall_len = np.linalg.norm(wall_vec)
        if wall_len == 0: continue
        wall_unit_vec = wall_vec / wall_len
        wall_normal = np.array([-wall_unit_vec[1], wall_unit_vec[0]])
        door_start_pt = p1 + wall_unit_vec * door["position"]
        door_end_pt = door_start_pt + wall_unit_vec * door["width"]
        door_start_scaled = (door_start_pt[0] * scale + offset_x, door_start_pt[1] * scale + offset_y)
        door_end_scaled = (door_end_pt[0] * scale + offset_x, door_end_pt[1] * scale + offset_y)
        thickness = app_data.current_floorplan_data.get("wall_thickness", 20)
        scaled_thickness = max(3, int(thickness * scale))
        draw_style = door.get("draw_style", "Swinging")
        if draw_style == "Sliding":
            cv2.line(img, tuple(np.int32(door_start_scaled)), tuple(np.int32(door_end_scaled)), (255,255,255), scaled_thickness)
            sliding_door_color = (0, 165, 255)
            cv2.line(img, tuple(np.int32(door_start_scaled)), tuple(np.int32(door_end_scaled)), sliding_door_color, 3)
        elif draw_style == "DoubleSwinging":
            cv2.line(img, tuple(np.int32(door_start_scaled)), tuple(np.int32(door_end_scaled)), (255, 255, 255), scaled_thickness)
            mid_pt = (np.array(door_start_scaled) + np.array(door_end_scaled)) / 2
            door_width_scaled = door["width"] * scale; leaf_width_scaled = door_width_scaled / 2
            draw_swinging_door(img, door, scale, door_start_scaled, mid_pt, leaf_width_scaled, wall_unit_vec, wall_normal, scaled_thickness, "Left Hand")
            draw_swinging_door(img, door, scale, door_end_scaled, mid_pt, leaf_width_scaled, -wall_unit_vec, wall_normal, scaled_thickness, "Right Hand")
        else:
            cv2.line(img, tuple(np.int32(door_start_scaled)), tuple(np.int32(door_end_scaled)), (255, 255, 255), scaled_thickness)
            door_width_scaled = door["width"] * scale
            draw_swinging_door(img, door, scale, door_start_scaled, door_end_scaled, door_width_scaled, wall_unit_vec, wall_normal, scaled_thickness, door["hinge"])

def draw_swinging_door(img, door, scale, start_pt, end_pt, width_scaled, wall_unit_vec, wall_normal, scaled_thickness, hinge_side):
    # ... (This function is unchanged) ...
    door_color = tuple(door.get("color_bgr", [150, 75, 0])); swing_dir = -1 if door["swing"] == "In-swing" else 1
    if hinge_side == "Left Hand": hinge_surface_pt = np.array(start_pt)
    else: hinge_surface_pt = np.array(start_pt)
    hinge_inset_pt = hinge_surface_pt + wall_normal * (scaled_thickness / 2) * swing_dir
    latch_surface_pt = np.array(end_pt); latch_inset_pt = latch_surface_pt + wall_normal * (scaled_thickness / 2) * swing_dir
    open_door_vec = latch_inset_pt - hinge_inset_pt; rotation_dir = swing_dir
    if hinge_side == "Right Hand": rotation_dir *= -1
    rotated_vec = np.array([-open_door_vec[1], open_door_vec[0]]) * rotation_dir
    open_latch_pt = hinge_inset_pt + rotated_vec
    door_panel_thickness_scaled = max(2, int(5 * scale))
    thickness_vec = wall_normal * door_panel_thickness_scaled * swing_dir
    p1 = hinge_inset_pt - thickness_vec; p2 = open_latch_pt - thickness_vec; p3 = open_latch_pt; p4 = hinge_inset_pt
    door_contour = np.array([p1, p2, p3, p4], dtype=np.int32)
    cv2.fillPoly(img, [door_contour], door_color)
    axes = (int(width_scaled), int(width_scaled)); wall_angle_deg = math.degrees(math.atan2(wall_unit_vec[1], wall_unit_vec[0]))
    if hinge_side == "Left Hand": start_angle, end_angle = wall_angle_deg, wall_angle_deg + (90 * swing_dir)
    else: start_angle, end_angle = wall_angle_deg, wall_angle_deg + (-90 * swing_dir)
    draw_dashed_ellipse(img, hinge_inset_pt, axes, int(wall_angle_deg), int(start_angle - wall_angle_deg), int(end_angle - wall_angle_deg), door_color, 1)