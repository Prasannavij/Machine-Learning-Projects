import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from PIL import Image, ImageTk
import json
import numpy as np
import cv2
import os
import math

# --- Constants ---
CANVAS_WIDTH = 700
CANVAS_HEIGHT = 650
CANVAS_PADDING = 50
FONT = cv2.FONT_HERSHEY_SIMPLEX
FONT_SCALE = 0.5
FONT_COLOR_RED = (0, 0, 255) # BGR format for red
FONT_THICKNESS = 1
DOOR_COLOR = (150, 75, 0) # Brown color for door symbols

class FloorplanGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Room Floorplan Generator")
        self.root.geometry("1100x800")

        # --- State Variables ---
        self.current_floorplan_data = None 
        self.save_counter = 1
        self.scratch_points = []
        self.is_scratch_closed = False
        self.doors_on_plan = []
        self.wall_definitions = {}
        self.current_canvas_image = None

        # --- UI Layout ---
        top_frame = ttk.Frame(root, height=60)
        top_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)
        top_frame.pack_propagate(False)
        self.reset_all_btn = ttk.Button(top_frame, text="Reset All", command=self.reset_application)
        self.reset_all_btn.pack(side=tk.LEFT, padx=5, pady=10)
        self.compass_canvas = tk.Canvas(top_frame, width=100, height=100, bg=root.cget('bg'), highlightthickness=0)
        self.compass_canvas.pack(side=tk.RIGHT)
        self.draw_tk_compass()

        main_frame = ttk.Frame(root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        left_frame = ttk.Frame(main_frame, width=350)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_frame.pack_propagate(False)
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.notebook = ttk.Notebook(left_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        self.tab_template = ttk.Frame(self.notebook, padding="10")
        self.tab_custom = ttk.Frame(self.notebook, padding="10")
        self.tab_scratch = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(self.tab_template, text="Select Template")
        self.notebook.add(self.tab_custom, text="Custom Rectangle")
        self.notebook.add(self.tab_scratch, text="Draw from Scratch")
        
        self.canvas = tk.Canvas(right_frame, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg="white", relief="sunken", borderwidth=1)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.tk_image = None

        self.shapes = self.load_json("room_shapes.json", "Room Shapes")
        self.door_types = self.load_json("doors.json", "Door Types")
        
        self.setup_template_tab()
        self.setup_custom_tab()
        self.setup_scratch_tab()
        
        self.reset_application()

    def draw_tk_compass(self):
        c=self.compass_canvas; c.delete("all"); w,h=100,100; cx,cy=w/2,h/2; r=35
        c.create_line(cx,cy,cx,cy-r,arrow=tk.LAST,width=2,fill="black"); c.create_text(cx,cy-r-10,text="N",font=("Arial",10,"bold"))
        c.create_line(cx,cy,cx,cy+r,width=1,fill="grey"); c.create_line(cx,cy,cx+r,cy,width=1,fill="grey"); c.create_line(cx,cy,cx-r,cy,width=1,fill="grey")
        c.create_text(cx,cy+r+10,text="S",font=("Arial",9)); c.create_text(cx+r+10,cy,text="E",font=("Arial",9)); c.create_text(cx-r-10,cy,text="W",font=("Arial",9))
    
    def load_json(self, filename, file_description):
        try:
            with open(filename, "r") as f: return json.load(f)
        except Exception as e:
            messagebox.showerror("Error", f"Could not load {file_description} from {filename}:\n{e}"); return {}

    def create_door_controls(self, parent_tab):
        door_frame = ttk.LabelFrame(parent_tab, text="Add a Door"); door_frame.pack(fill=tk.X, pady=(20, 0)); door_frame.columnconfigure(1, weight=1)
        ttk.Label(door_frame, text="On Wall:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        wall_var = tk.StringVar(); wall_combo = ttk.Combobox(door_frame, textvariable=wall_var, state="disabled")
        wall_combo.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Position (from start):").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        pos_entry = ttk.Entry(door_frame, state="disabled"); pos_entry.insert(0, "50")
        pos_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Door Type:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        type_var = tk.StringVar(); type_combo = ttk.Combobox(door_frame, textvariable=type_var, values=list(self.door_types.keys()), state="disabled")
        if self.door_types: type_combo.current(0)
        type_combo.grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Hinge Side:").grid(row=3, column=0, padx=5, pady=5, sticky="w")
        hinge_var = tk.StringVar(value="Left Hand"); hinge_combo = ttk.Combobox(door_frame, textvariable=hinge_var, values=["Left Hand", "Right Hand"], state="disabled")
        hinge_combo.grid(row=3, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Swing Direction:").grid(row=4, column=0, padx=5, pady=5, sticky="w")
        swing_var = tk.StringVar(value="In-swing"); swing_combo = ttk.Combobox(door_frame, textvariable=swing_var, values=["In-swing", "Out-swing"], state="disabled")
        swing_combo.grid(row=4, column=1, padx=5, pady=5, sticky="ew")
        add_btn = ttk.Button(door_frame, text="Add Door", state="disabled", command=lambda: self.add_door_to_plan(wall_var, pos_entry, type_var, hinge_var, swing_var))
        add_btn.grid(row=5, column=0, columnspan=2, pady=10, sticky="ew")
        return {"frame": door_frame, "wall_combo": wall_combo, "pos_entry": pos_entry, "type_combo": type_combo, "hinge_combo": hinge_combo, "swing_combo": swing_combo, "add_btn": add_btn}

    def setup_template_tab(self):
        label = ttk.Label(self.tab_template, text="Select a predefined room shape:"); label.pack(pady=(0, 5), fill=tk.X)
        self.shape_var = tk.StringVar(); shape_dropdown = ttk.Combobox(self.tab_template, textvariable=self.shape_var, values=list(self.shapes.keys()), state="readonly")
        if self.shapes: shape_dropdown.current(0)
        shape_dropdown.pack(pady=5, fill=tk.X)
        ttk.Label(self.tab_template, text="Wall Thickness:").pack(pady=(10, 0))
        self.template_thickness_entry = ttk.Entry(self.tab_template); self.template_thickness_entry.insert(0, "20"); self.template_thickness_entry.pack(pady=5, fill=tk.X)
        draw_btn = ttk.Button(self.tab_template, text="Draw Template Shape", command=self.draw_template_shape); draw_btn.pack(pady=10, fill=tk.X)
        self.save_template_btn = ttk.Button(self.tab_template, text="Save as JSON & Image", command=self.save_floorplan, state="disabled"); self.save_template_btn.pack(pady=5, fill=tk.X)
        self.template_door_controls = self.create_door_controls(self.tab_template)

    def setup_custom_tab(self):
        grid_frame = ttk.Frame(self.tab_custom); grid_frame.pack(fill=tk.X); grid_frame.columnconfigure(1, weight=1)
        ttk.Label(grid_frame, text="Room Width:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        self.width_entry = ttk.Entry(grid_frame); self.width_entry.insert(0, "400"); self.width_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=2)
        ttk.Label(grid_frame, text="Room Height:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        self.height_entry = ttk.Entry(grid_frame); self.height_entry.insert(0, "300"); self.height_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=2)
        ttk.Label(grid_frame, text="Wall Thickness:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
        self.thickness_entry = ttk.Entry(grid_frame); self.thickness_entry.insert(0, "20"); self.thickness_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=2)
        draw_btn = ttk.Button(self.tab_custom, text="Draw Custom Room", command=self.draw_custom_room); draw_btn.pack(pady=20, fill=tk.X)
        self.save_custom_btn = ttk.Button(self.tab_custom, text="Save as JSON & Image", command=self.save_floorplan, state="disabled"); self.save_custom_btn.pack(pady=5, fill=tk.X)
        self.custom_door_controls = self.create_door_controls(self.tab_custom)

    def setup_scratch_tab(self):
        properties_frame = ttk.LabelFrame(self.tab_scratch, text="Room Properties"); properties_frame.pack(fill=tk.X, pady=(0, 10)); properties_frame.columnconfigure(1, weight=1)
        ttk.Label(properties_frame, text="Wall Height:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.scratch_height_entry = ttk.Entry(properties_frame); self.scratch_height_entry.insert(0, "250"); self.scratch_height_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(properties_frame, text="Wall Thickness:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.scratch_thickness_entry = ttk.Entry(properties_frame); self.scratch_thickness_entry.insert(0, "20"); self.scratch_thickness_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        wall_frame = ttk.LabelFrame(self.tab_scratch, text="Add a Wall Segment"); wall_frame.pack(fill=tk.X); wall_frame.columnconfigure(1, weight=1)
        self.scratch_status_label = ttk.Label(wall_frame, text="Start Point: (0, 0)"); self.scratch_status_label.grid(row=0, column=0, columnspan=2, pady=5)
        ttk.Label(wall_frame, text="Length:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.scratch_length_entry = ttk.Entry(wall_frame); self.scratch_length_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(wall_frame, text="Direction:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.scratch_direction_var = tk.StringVar(); directions = ["Right (East)", "Up (North)", "Left (West)", "Down (South)"]
        self.scratch_direction_combo = ttk.Combobox(wall_frame, textvariable=self.scratch_direction_var, values=directions, state="readonly")
        self.scratch_direction_combo.current(0); self.scratch_direction_combo.grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        buttons_frame = ttk.Frame(self.tab_scratch); buttons_frame.pack(pady=15, fill=tk.X); buttons_frame.columnconfigure((0,1), weight=1)
        self.add_wall_btn = ttk.Button(buttons_frame, text="Add Wall", command=self.add_scratch_wall); self.add_wall_btn.grid(row=0, column=0, sticky="ew", padx=2)
        self.close_shape_btn = ttk.Button(buttons_frame, text="Close Shape", command=self.close_scratch_shape); self.close_shape_btn.grid(row=0, column=1, sticky="ew", padx=2)
        self.save_scratch_btn = ttk.Button(self.tab_scratch, text="Save as JSON & Image", command=self.save_floorplan, state="disabled"); self.save_scratch_btn.pack(pady=10, fill=tk.X)
        self.scratch_door_controls = self.create_door_controls(self.tab_scratch)

    def identify_walls(self, coords):
        self.wall_definitions = {}
        if len(coords) < 2: return []
        center_x = np.mean([p[0] for p in coords]); center_y = np.mean([p[1] for p in coords])
        counts = {"North": 0, "South": 0, "East": 0, "West": 0, "Angled": 0}
        
        is_closed = self.is_scratch_closed or self.current_floorplan_data['type'] != 'scratch'
        num_segments = len(coords) if is_closed else len(coords) - 1

        for i in range(num_segments):
            p1 = coords[i]; p2 = coords[(i + 1) % len(coords)]
            mid_x, mid_y = (p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]

            label = ""; tolerance = 1e-9
            if abs(dx) > abs(dy) + tolerance:
                if mid_y < center_y: label = "North"
                else: label = "South"
            elif abs(dy) > abs(dx) + tolerance:
                if mid_x > center_x: label = "East"
                else: label = "West"
            else: label = "Angled"
            
            counts[label] += 1
            wall_label = f"{label} Wall {counts[label]}"
            self.wall_definitions[wall_label] = {"p1": p1, "p2": p2}
        return list(self.wall_definitions.keys())

    def set_door_controls_state(self, controls, state="normal"):
        for widget in controls.values():
            if 'state' in widget.keys(): widget.config(state=state)
        if state == "normal" and self.current_floorplan_data:
            coords = self.current_floorplan_data.get("coordinates", [])
            wall_labels = self.identify_walls(coords)
            controls["wall_combo"]["values"] = wall_labels
            if wall_labels: controls["wall_combo"].current(0)
    
    def add_door_to_plan(self, wall_var, pos_entry, type_var, hinge_var, swing_var):
        if not self.current_floorplan_data: return
        try:
            wall_label = wall_var.get()
            if not wall_label: messagebox.showerror("Error", "Please select a wall."); return
            position = float(pos_entry.get())
            door_type_name = type_var.get()
            door_info = self.door_types[door_type_name]
            door_width = door_info["width"]; door_color = door_info["color_bgr"]
            p1 = self.wall_definitions[wall_label]["p1"]; p2 = self.wall_definitions[wall_label]["p2"]
            wall_length = math.hypot(p2[0] - p1[0], p2[1] - p1[1])
            if position + door_width > wall_length:
                messagebox.showerror("Error", f"Door does not fit. Wall Length: {wall_length:.0f}, Door End: {position+door_width:.0f}"); return
        except Exception as e:
            messagebox.showerror("Invalid Input", f"Please check your door parameters.\nError: {e}"); return
        door_data = {"wall_label": wall_label, "position": position, "width": door_width, "type": door_type_name, 
                     "hinge": hinge_var.get(), "swing": swing_var.get(), "color_bgr": door_color}
        self.doors_on_plan.append(door_data)
        self.redraw_canvas()

    def redraw_canvas(self):
        if not self.current_floorplan_data: return
        data_type = self.current_floorplan_data["type"]
        if data_type == 'scratch': self.redraw_scratch_canvas()
        elif data_type == 'template': self.draw_template_shape(redraw_only=True)
        elif data_type == 'custom_rectangle': self.draw_custom_room(redraw_only=True)
            
    def draw_doors(self, img, scale, offset_x, offset_y):
        if not self.doors_on_plan: return
        for door in self.doors_on_plan:
            wall = self.wall_definitions.get(door["wall_label"])
            if not wall: continue
            door_color = tuple(door.get("color_bgr", [150, 75, 0]))
            p1 = np.array(wall["p1"]); p2 = np.array(wall["p2"])
            wall_vec = p2 - p1; wall_len = np.linalg.norm(wall_vec)
            if wall_len == 0: continue
            wall_unit_vec = wall_vec / wall_len
            door_start_pt = p1 + wall_unit_vec * door["position"]
            door_end_pt = door_start_pt + wall_unit_vec * door["width"]
            door_width_scaled = door["width"] * scale
            door_start_scaled = (door_start_pt[0] * scale + offset_x, door_start_pt[1] * scale + offset_y)
            door_end_scaled = (door_end_pt[0] * scale + offset_x, door_end_pt[1] * scale + offset_y)
            
            thickness = self.current_floorplan_data.get("wall_thickness", 20)
            scaled_thickness = max(3, int(thickness * scale))
            cv2.line(img, tuple(np.int32(door_start_scaled)), tuple(np.int32(door_end_scaled)), (255, 255, 255), scaled_thickness)
            
            swing_dir = -1 if door["swing"] == "In-swing" else 1
            if door["hinge"] == "Left Hand":
                hinge_pt = door_start_scaled; swing_from_pt = door_end_scaled
            else: # Right Hand
                hinge_pt = door_end_scaled; swing_from_pt = door_start_scaled
                
            open_door_vec = np.array(swing_from_pt) - np.array(hinge_pt)
            rotated_vec = np.array([-open_door_vec[1], open_door_vec[0]]) * swing_dir
            open_door_pt = (np.array(hinge_pt) + rotated_vec).astype(int)
            
            cv2.line(img, tuple(np.int32(hinge_pt)), tuple(open_door_pt), door_color, 2)
            
            axes = (int(door_width_scaled), int(door_width_scaled))
            wall_angle_deg = math.degrees(math.atan2(wall_unit_vec[1], wall_unit_vec[0]))
            
            if door["hinge"] == "Left Hand":
                start_angle = wall_angle_deg; end_angle = wall_angle_deg + (90 * swing_dir)
            else:
                start_angle = wall_angle_deg + 180; end_angle = wall_angle_deg + 180 + (-90 * swing_dir)
            cv2.ellipse(img, tuple(np.int32(hinge_pt)), axes, 0, start_angle, end_angle, door_color, 1)

    def add_measurement_text(self, img, coords, final_coords):
        if len(coords) < 2: return
        is_closed = self.is_scratch_closed or self.current_floorplan_data['type'] != 'scratch'
        num_segments = len(coords) if is_closed else len(coords) - 1

        for i in range(num_segments):
            p1_orig = coords[i]; p2_orig = coords[(i + 1) % len(coords)]
            p1_scaled = final_coords[i]; p2_scaled = final_coords[(i + 1) % len(final_coords)]
            length = np.linalg.norm(np.array(p1_orig) - np.array(p2_orig))
            midpoint = ((p1_scaled[0] + p2_scaled[0]) / 2, (p1_scaled[1] + p2_scaled[1]) / 2)
            text = f"{length:.0f}"; text_size, _ = cv2.getTextSize(text, FONT, FONT_SCALE, FONT_THICKNESS)
            label_pos = list(midpoint)
            if abs(p1_scaled[0] - p2_scaled[0]) > abs(p1_scaled[1] - p2_scaled[1]):
                label_pos[0] -= text_size[0] / 2; label_pos[1] -= 20
            else:
                label_pos[0] -= text_size[0] + 20; label_pos[1] += text_size[1] / 2
            cv2.putText(img, text, (int(label_pos[0]), int(label_pos[1])), FONT, FONT_SCALE, FONT_COLOR_RED, FONT_THICKNESS)

    def draw_template_shape(self, redraw_only=False):
        if not redraw_only:
            try: thickness = float(self.template_thickness_entry.get())
            except (ValueError, TypeError): messagebox.showerror("Invalid Input", "Please enter a valid thickness."); return
            selected_shape_name = self.shape_var.get(); shape_data = self.shapes.get(selected_shape_name)
            if not shape_data or "coordinates" not in shape_data: return
            self.current_floorplan_data = {"type": "template", "name": selected_shape_name, "coordinates": shape_data["coordinates"], "wall_thickness": thickness}
            self.doors_on_plan = []; self.save_template_btn.config(state="normal"); self.set_door_controls_state(self.template_door_controls, "normal")
            self.set_door_controls_state(self.custom_door_controls, "disabled"); self.set_door_controls_state(self.scratch_door_controls, "disabled")

        coords = self.current_floorplan_data["coordinates"]; thickness = self.current_floorplan_data["wall_thickness"]
        min_x, min_y = np.min(coords, axis=0); max_x, max_y = np.max(coords, axis=0)
        shape_width = max(1, max_x - min_x); shape_height = max(1, max_y - min_y)
        scale = min((self.canvas.winfo_width() - 2 * CANVAS_PADDING) / shape_width, (self.canvas.winfo_height() - 2 * CANVAS_PADDING) / shape_height)
        offset_x = (self.canvas.winfo_width() - shape_width * scale) / 2 - min_x * scale
        offset_y = (self.canvas.winfo_height() - shape_height * scale) / 2 - min_y * scale
        final_coords = [(p[0] * scale + offset_x, p[1] * scale + offset_y) for p in coords]
        
        img = np.ones((self.canvas.winfo_height(), self.canvas.winfo_width(), 3), dtype=np.uint8) * 255
        
        # --- FIXED: Use thick polylines and fill for consistent drawing ---
        final_coords_np = np.array(final_coords, dtype=np.int32)
        scaled_thickness = max(2, int(thickness * scale))
        cv2.polylines(img, [final_coords_np], isClosed=True, color=(50,50,50), thickness=scaled_thickness)
        cv2.fillPoly(img, [final_coords_np], color=(235, 245, 255)) # Light fill color
        
        self.add_measurement_text(img, coords, final_coords)
        self.draw_doors(img, scale, offset_x, offset_y)
        self.display_image_on_canvas(img)
        
    def draw_custom_room(self, redraw_only=False):
        if not redraw_only:
            try: width = float(self.width_entry.get()); height = float(self.height_entry.get()); thickness = float(self.thickness_entry.get())
            except ValueError: return
            self.current_floorplan_data = {"type": "custom_rectangle", "inner_width": width, "inner_height": height, "wall_thickness": thickness}
            self.current_floorplan_data["coordinates"] = [[0,0], [width, 0], [width, height], [0, height]]
            self.doors_on_plan = []; self.save_custom_btn.config(state="normal"); self.set_door_controls_state(self.custom_door_controls, "normal")
            self.set_door_controls_state(self.template_door_controls, "disabled"); self.set_door_controls_state(self.scratch_door_controls, "disabled")
        
        width = self.current_floorplan_data["inner_width"]; height = self.current_floorplan_data["inner_height"]; thickness = self.current_floorplan_data["wall_thickness"]
        total_width = width + 2*thickness; total_height = height + 2*thickness
        scale = min((self.canvas.winfo_width() - 2 * CANVAS_PADDING) / total_width, (self.canvas.winfo_height() - 2 * CANVAS_PADDING) / total_height)
        s_total_w = int(total_width * scale); s_total_h = int(total_height * scale); s_thick = int(thickness * scale)
        offset_x = (self.canvas.winfo_width() - s_total_w) // 2; offset_y = (self.canvas.winfo_height() - s_total_h) // 2
        p1_outer, p2_outer = (offset_x, offset_y), (offset_x + s_total_w, offset_y + s_total_h)
        img = np.ones((self.canvas.winfo_height(), self.canvas.winfo_width(), 3), dtype=np.uint8) * 255
        cv2.rectangle(img, p1_outer, p2_outer, color=(50, 50, 50), thickness=cv2.FILLED)
        p1_inner = (p1_outer[0] + s_thick, p1_outer[1] + s_thick); p2_inner = (p2_outer[0] - s_thick, p2_outer[1] - s_thick)
        cv2.rectangle(img, p1_inner, p2_inner, color=(255, 255, 255), thickness=cv2.FILLED)
        
        width_text = f"{width:.0f}"; w_text_size, _ = cv2.getTextSize(width_text, FONT, FONT_SCALE, FONT_THICKNESS)
        w_pos = ((p1_inner[0] + p2_inner[0]) // 2 - w_text_size[0] // 2, p1_inner[1] + w_text_size[0] + 15)
        cv2.putText(img, width_text, w_pos, FONT, FONT_SCALE, FONT_COLOR_RED, FONT_THICKNESS)
        height_text = f"{height:.0f}"; h_text_size, _ = cv2.getTextSize(height_text, FONT, FONT_SCALE, FONT_THICKNESS)
        h_pos = (p1_inner[0] + 15, (p1_inner[1] + p2_inner[1]) // 2 + h_text_size[1] // 2)
        cv2.putText(img, height_text, h_pos, FONT, FONT_SCALE, FONT_COLOR_RED, FONT_THICKNESS)

        self.draw_doors(img, scale, p1_inner[0], p1_inner[1])
        self.display_image_on_canvas(img)

    def redraw_scratch_canvas(self):
        if not self.scratch_points or not self.current_floorplan_data: return
        coords = self.current_floorplan_data["coordinates"]; thickness = self.current_floorplan_data["wall_thickness"]
        min_x, min_y = np.min(coords, axis=0); max_x, max_y = np.max(coords, axis=0)
        shape_width = max(1, max_x-min_x); shape_height = max(1, max_y-min_y)
        scale = min((self.canvas.winfo_width() - 2 * CANVAS_PADDING) / shape_width, (self.canvas.winfo_height() - 2 * CANVAS_PADDING) / shape_height)
        offset_x = (self.canvas.winfo_width() - shape_width*scale)/2 - min_x*scale
        offset_y = (self.canvas.winfo_height() - shape_height*scale)/2 - min_y*scale
        final_coords = [(p[0]*scale + offset_x, p[1]*scale + offset_y) for p in coords]
        img = np.ones((self.canvas.winfo_height(), self.canvas.winfo_width(), 3), dtype=np.uint8) * 255
        
        final_coords_np = np.array(final_coords, dtype=np.int32)
        scaled_thickness = max(2, int(thickness * scale))
        
        if self.is_scratch_closed:
            cv2.polylines(img, [final_coords_np], isClosed=True, color=(50,50,50), thickness=scaled_thickness)
            cv2.fillPoly(img, [final_coords_np], color=(235, 245, 255))
        else:
            cv2.polylines(img, [final_coords_np], isClosed=False, color=(0,0,0), thickness=2)
            if len(final_coords) > 0:
                cv2.circle(img, tuple(np.int32(final_coords[0])), 5, (0, 128, 0), -1)
                cv2.circle(img, tuple(np.int32(final_coords[-1])), 5, (0, 0, 255), -1)
        
        self.add_measurement_text(img, coords, final_coords)
        self.draw_doors(img, scale, offset_x, offset_y)
        self.display_image_on_canvas(img)
    
    def close_scratch_shape(self):
        if len(self.scratch_points) < 3: messagebox.showwarning("Warning", "You need at least 3 points to create a closed shape."); return
        self.is_scratch_closed = True; self.add_wall_btn.config(state="disabled"); self.close_shape_btn.config(state="disabled")
        self.current_floorplan_data['wall_thickness'] = float(self.scratch_thickness_entry.get() or 20)
        self.current_floorplan_data['wall_height'] = float(self.scratch_height_entry.get() or 250)
        self.doors_on_plan = []
        self.redraw_canvas()
        self.save_scratch_btn.config(state="normal"); self.set_door_controls_state(self.scratch_door_controls, "normal")
        self.set_door_controls_state(self.template_door_controls, "disabled"); self.set_door_controls_state(self.custom_door_controls, "disabled")

    def reset_application(self):
        self.scratch_points = [[0, 0]]; self.is_scratch_closed = False; self.current_floorplan_data = None; self.doors_on_plan = []
        
        if hasattr(self, 'add_wall_btn'):
            self.add_wall_btn.config(state="normal"); self.close_shape_btn.config(state="normal"); self.save_scratch_btn.config(state="disabled")
            self.set_door_controls_state(self.scratch_door_controls, "disabled")
            self.scratch_status_label.config(text="Start Point: (0, 0)")
        if hasattr(self, 'save_template_btn'):
            self.save_template_btn.config(state="disabled"); self.set_door_controls_state(self.template_door_controls, "disabled")
        if hasattr(self, 'save_custom_btn'):
            self.save_custom_btn.config(state="disabled"); self.set_door_controls_state(self.custom_door_controls, "disabled")
        
        self.canvas.delete("all")
        self.current_canvas_image = None
        self.root.update_idletasks()
        img = np.ones((self.canvas.winfo_height(), self.canvas.winfo_width(), 3), dtype=np.uint8) * 255
        if self.canvas.winfo_height() > 1 and self.canvas.winfo_width() > 1:
            cv2.putText(img, "Select an option on the left to begin.", (50, self.canvas.winfo_height() // 2), FONT, 0.7, (128,128,128), 1)
        self.display_image_on_canvas(img)
        if hasattr(self, 'notebook'): self.notebook.select(self.tab_template)

    def add_scratch_wall(self):
        try: length = float(self.scratch_length_entry.get())
        except (ValueError, TypeError): messagebox.showerror("Invalid Input", "Please enter a positive number for the wall length."); return
        direction=self.scratch_direction_var.get(); last_point=self.scratch_points[-1]; dx,dy=0,0
        if direction == "Right (East)": dx=length
        elif direction == "Up (North)": dy=-length
        elif direction == "Left (West)": dx=-length
        elif direction == "Down (South)": dy=length
        new_point = [last_point[0]+dx, last_point[1]+dy]
        self.scratch_points.append(new_point); self.scratch_status_label.config(text=f"Current Point: ({new_point[0]:.1f}, {new_point[1]:.1f})")
        self.current_floorplan_data = {"type": "scratch", "coordinates": self.scratch_points, "wall_thickness": float(self.scratch_thickness_entry.get() or 20)}
        self.redraw_canvas()
        
    def save_floorplan(self):
        if self.current_floorplan_data is None or self.current_canvas_image is None: 
            messagebox.showwarning("No Data", "There is no floorplan on the canvas to save."); return
            
        self.current_floorplan_data['doors'] = self.doors_on_plan
        initial_filename = f"floorplan_{self.save_counter}"
        filepath = filedialog.asksaveasfilename(initialfile=f"{initial_filename}.json", defaultextension=".json", filetypes=[("JSON Files", "*.json")])
        if not filepath: return
        
        json_path = filepath
        image_path = f"{os.path.splitext(json_path)[0]}.png"

        try:
            with open(json_path, "w") as f: 
                json.dump(self.current_floorplan_data, f, indent=4, default=lambda o: o.tolist() if isinstance(o, np.ndarray) else o)
            cv2.imwrite(image_path, self.current_canvas_image)
            messagebox.showinfo("Success", f"Saved successfully!\nJSON: {os.path.basename(json_path)}\nImage: {os.path.basename(image_path)}")
            self.save_counter += 1
        except Exception as e: 
            messagebox.showerror("Save Error", f"An error occurred while saving the files:\n{e}")

    def display_image_on_canvas(self, cv2_img):
        self.current_canvas_image = cv2_img
        rgb_img = cv2.cvtColor(cv2_img, cv2.COLOR_BGR2RGB); pil_img = Image.fromarray(rgb_img)
        self.tk_image = ImageTk.PhotoImage(image=pil_img)
        self.canvas.delete("all"); self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_image)

if __name__ == "__main__":
    root = tk.Tk()
    app = FloorplanGeneratorApp(root)
    root.mainloop()