import tkinter as tk
from tkinter import ttk

class UIManager:
    def __init__(self, app):
        self.app = app

    def setup_ui(self):
        """Creates the entire UI structure and all widgets."""
        top_frame = ttk.Frame(self.app.root, height=60)
        top_frame.pack(side=tk.TOP, fill=tk.X, padx=10, pady=5)
        top_frame.pack_propagate(False)
        
        self.app.reset_all_btn = ttk.Button(top_frame, text="Reset All", command=self.app.reset_application)
        self.app.reset_all_btn.pack(side=tk.LEFT, padx=5, pady=10)

        # --- NEW: Add Zoom In/Out buttons ---
        zoom_in_btn = ttk.Button(top_frame, text="+", command=self.app.zoom_in, width=3)
        zoom_in_btn.pack(side=tk.LEFT, pady=10)
        zoom_out_btn = ttk.Button(top_frame, text="-", command=self.app.zoom_out, width=3)
        zoom_out_btn.pack(side=tk.LEFT, padx=2, pady=10)

        self.app.compass_canvas = tk.Canvas(top_frame, width=100, height=100, bg=self.app.root.cget('bg'), highlightthickness=0)
        self.app.compass_canvas.pack(side=tk.RIGHT)
        self.draw_tk_compass()

        main_frame = ttk.Frame(self.app.root); main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # --- SCROLLABLE LEFT PANEL START ---
        left_frame = ttk.Frame(main_frame, width=350)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_frame.pack_propagate(False)

        # Create a canvas and a vertical scrollbar for the left panel
        left_canvas = tk.Canvas(left_frame, borderwidth=0, highlightthickness=0)
        vscroll = ttk.Scrollbar(left_frame, orient="vertical", command=left_canvas.yview)
        left_canvas.configure(yscrollcommand=vscroll.set)
        left_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vscroll.pack(side=tk.RIGHT, fill=tk.Y)

        # Create a frame inside the canvas to hold all input widgets
        self.scrollable_left = ttk.Frame(left_canvas)
        self.scrollable_left.bind(
            "<Configure>",
            lambda e: left_canvas.configure(scrollregion=left_canvas.bbox("all"))
        )
        left_canvas.create_window((0, 0), window=self.scrollable_left, anchor="nw")

        # Enable mousewheel scrolling on Windows
        def _on_mousewheel(event):
            left_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        left_canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # --- SCROLLABLE LEFT PANEL END ---

        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        right_frame.grid_rowconfigure(0, weight=1)
        right_frame.grid_columnconfigure(0, weight=1)
        self.app.notebook = ttk.Notebook(self.scrollable_left)
        self.app.notebook.pack(fill=tk.BOTH, expand=True)
        self.app.tab_template = ttk.Frame(self.app.notebook, padding="10")
        self.app.tab_custom = ttk.Frame(self.app.notebook, padding="10")
        self.app.tab_scratch = ttk.Frame(self.app.notebook, padding="10")
        self.app.notebook.add(self.app.tab_template, text="Select Template")
        self.app.notebook.add(self.app.tab_custom, text="Custom Rectangle")
        self.app.notebook.add(self.app.tab_scratch, text="Draw from Scratch")
        self.app.canvas = tk.Canvas(right_frame, bg="white", relief="sunken", borderwidth=1)
        self.app.canvas.grid(row=0, column=0, sticky="nsew")

        self.setup_template_tab()
        self.setup_custom_tab()
        self.setup_scratch_tab()

    def draw_tk_compass(self):
        c=self.app.compass_canvas; c.delete("all"); w,h=100,100; cx,cy=w/2,h/2; r=35
        c.create_line(cx,cy,cx,cy-r,arrow=tk.LAST,width=2,fill="black"); c.create_text(cx,cy-r-10,text="N",font=("Arial",10,"bold"))
        c.create_line(cx,cy,cx,cy+r,width=1,fill="grey"); c.create_line(cx,cy,cx+r,cy,width=1,fill="grey"); c.create_line(cx,cy,cx-r,cy,width=1,fill="grey")
        c.create_text(cx,cy+r+10,text="S",font=("Arial",9)); c.create_text(cx+r+10,cy,text="E",font=("Arial",9)); c.create_text(cx-r-10,cy,text="W",font=("Arial",9))

    def create_door_controls(self, parent_tab):
        door_frame = ttk.LabelFrame(parent_tab, text="Add a Door"); door_frame.pack(fill=tk.X, pady=(20, 0)); door_frame.columnconfigure(1, weight=1)
        ttk.Label(door_frame, text="On Wall:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        wall_var = tk.StringVar(); wall_combo = ttk.Combobox(door_frame, textvariable=wall_var, state="disabled")
        wall_combo.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Position (from start):").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        pos_entry = ttk.Entry(door_frame, state="disabled"); pos_entry.insert(0, "50")
        pos_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Door Type:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        type_var = tk.StringVar(); type_combo = ttk.Combobox(door_frame, textvariable=type_var, values=list(self.app.door_types.keys()), state="disabled")
        if self.app.door_types: type_combo.current(0)
        type_combo.grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Custom Width (opt):").grid(row=3, column=0, padx=5, pady=5, sticky="w")
        width_var = tk.StringVar(); width_entry = ttk.Entry(door_frame, textvariable=width_var, state="disabled")
        width_entry.grid(row=3, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Hinge Side:").grid(row=4, column=0, padx=5, pady=5, sticky="w")
        hinge_var = tk.StringVar(value="Left Hand"); hinge_combo = ttk.Combobox(door_frame, textvariable=hinge_var, values=["Left Hand", "Right Hand"], state="disabled")
        hinge_combo.grid(row=4, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(door_frame, text="Swing Direction:").grid(row=5, column=0, padx=5, pady=5, sticky="w")
        swing_var = tk.StringVar(value="In-swing"); swing_combo = ttk.Combobox(door_frame, textvariable=swing_var, values=["In-swing", "Out-swing"], state="disabled")
        swing_combo.grid(row=5, column=1, padx=5, pady=5, sticky="ew")
        add_btn = ttk.Button(door_frame, text="Add Door", state="disabled", command=lambda: self.app.add_door_to_plan(wall_var, pos_entry, type_var, hinge_var, swing_var, width_var))
        add_btn.grid(row=6, column=0, columnspan=2, pady=10, sticky="ew")
        return {"frame": door_frame, "wall_combo": wall_combo, "pos_entry": pos_entry, "type_combo": type_combo, "width_entry": width_entry, "hinge_combo": hinge_combo, "swing_combo": swing_combo, "add_btn": add_btn}

    def create_window_controls(self, parent_tab):
        win_frame = ttk.LabelFrame(parent_tab, text="Add a Window"); win_frame.pack(fill=tk.X, pady=(10, 0)); win_frame.columnconfigure(1, weight=1)
        ttk.Label(win_frame, text="On Wall:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        wall_var = tk.StringVar(); wall_combo = ttk.Combobox(win_frame, textvariable=wall_var, state="disabled")
        wall_combo.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(win_frame, text="Position (from start):").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        pos_entry = ttk.Entry(win_frame, state="disabled"); pos_entry.insert(0, "100")
        pos_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(win_frame, text="Window Type:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        type_var = tk.StringVar(); type_combo = ttk.Combobox(win_frame, textvariable=type_var, values=list(self.app.window_types.keys()), state="disabled")
        if self.app.window_types: type_combo.current(0)
        type_combo.grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(win_frame, text="Custom Width (opt):").grid(row=3, column=0, padx=5, pady=5, sticky="w")
        width_var = tk.StringVar(); width_entry = ttk.Entry(win_frame, textvariable=width_var, state="disabled")
        width_entry.grid(row=3, column=1, padx=5, pady=5, sticky="ew")
        add_btn = ttk.Button(win_frame, text="Add Window", state="disabled", command=lambda: self.app.add_window_to_plan(wall_var, pos_entry, type_var, width_var))
        add_btn.grid(row=4, column=0, columnspan=2, pady=10, sticky="ew")
        return {"frame": win_frame, "wall_combo": wall_combo, "pos_entry": pos_entry, "type_combo": type_combo, "width_entry": width_entry, "add_btn": add_btn}

    def setup_template_tab(self):
        parent = self.app.tab_template
        self.app.shape_var = tk.StringVar(); shape_dropdown = ttk.Combobox(parent, textvariable=self.app.shape_var, values=list(self.app.shapes.keys()), state="readonly")
        if self.app.shapes: shape_dropdown.current(0)
        ttk.Label(parent, text="Select a predefined room shape:").pack(pady=(0, 5), fill=tk.X)
        shape_dropdown.pack(pady=5, fill=tk.X)
        ttk.Label(parent, text="Wall Thickness:").pack(pady=(10, 0))
        self.app.template_thickness_entry = ttk.Entry(parent); self.app.template_thickness_entry.insert(0, "20"); self.app.template_thickness_entry.pack(pady=5, fill=tk.X)
        draw_btn = ttk.Button(parent, text="Draw Template Shape", command=self.app.draw_template_shape); draw_btn.pack(pady=10, fill=tk.X)
        self.app.save_template_btn = ttk.Button(parent, text="Save as JSON & Image", command=self.app.save_floorplan, state="disabled"); self.app.save_template_btn.pack(pady=5, fill=tk.X)
        self.app.template_door_controls = self.create_door_controls(parent)
        self.app.template_window_controls = self.create_window_controls(parent)

    def setup_custom_tab(self):
        parent = self.app.tab_custom
        grid_frame = ttk.Frame(parent); grid_frame.pack(fill=tk.X); grid_frame.columnconfigure(1, weight=1)
        ttk.Label(grid_frame, text="Room Width:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        self.app.width_entry = ttk.Entry(grid_frame); self.app.width_entry.insert(0, "400"); self.app.width_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=2)
        ttk.Label(grid_frame, text="Room Height:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        self.app.height_entry = ttk.Entry(grid_frame); self.app.height_entry.insert(0, "300"); self.app.height_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=2)
        ttk.Label(grid_frame, text="Wall Thickness:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
        self.app.thickness_entry = ttk.Entry(grid_frame); self.app.thickness_entry.insert(0, "20"); self.app.thickness_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=2)
        draw_btn = ttk.Button(parent, text="Draw Custom Room", command=self.app.draw_custom_room); draw_btn.pack(pady=20, fill=tk.X)
        self.app.save_custom_btn = ttk.Button(parent, text="Save as JSON & Image", command=self.app.save_floorplan, state="disabled"); self.app.save_custom_btn.pack(pady=5, fill=tk.X)
        self.app.custom_door_controls = self.create_door_controls(parent)
        self.app.custom_window_controls = self.create_window_controls(parent)

    def setup_scratch_tab(self):
        parent = self.app.tab_scratch
        properties_frame = ttk.LabelFrame(parent, text="Room Properties"); properties_frame.pack(fill=tk.X, pady=(0, 10)); properties_frame.columnconfigure(1, weight=1)
        ttk.Label(properties_frame, text="Wall Height:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.app.scratch_height_entry = ttk.Entry(properties_frame); self.app.scratch_height_entry.insert(0, "250"); self.app.scratch_height_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(properties_frame, text="Wall Thickness:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.app.scratch_thickness_entry = ttk.Entry(properties_frame); self.app.scratch_thickness_entry.insert(0, "20"); self.app.scratch_thickness_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        wall_frame = ttk.LabelFrame(parent, text="Add a Wall Segment"); wall_frame.pack(fill=tk.X); wall_frame.columnconfigure(1, weight=1)
        self.app.scratch_status_label = ttk.Label(wall_frame, text="Start Point: (0, 0)"); self.app.scratch_status_label.grid(row=0, column=0, columnspan=2, pady=5)
        ttk.Label(wall_frame, text="Length:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.app.scratch_length_entry = ttk.Entry(wall_frame); self.app.scratch_length_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")
        ttk.Label(wall_frame, text="Direction:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.app.scratch_direction_var = tk.StringVar(); directions = ["Right (East)", "Up (North)", "Left (West)", "Down (South)"]
        self.app.scratch_direction_combo = ttk.Combobox(wall_frame, textvariable=self.app.scratch_direction_var, values=directions, state="readonly")
        self.app.scratch_direction_combo.current(0); self.app.scratch_direction_combo.grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        buttons_frame = ttk.Frame(parent); buttons_frame.pack(pady=15, fill=tk.X); buttons_frame.columnconfigure((0,1), weight=1)
        self.app.add_wall_btn = ttk.Button(buttons_frame, text="Add Wall", command=self.app.add_scratch_wall); self.app.add_wall_btn.grid(row=0, column=0, sticky="ew", padx=2)
        self.app.close_shape_btn = ttk.Button(buttons_frame, text="Close Shape", command=self.app.close_scratch_shape); self.app.close_shape_btn.grid(row=0, column=1, sticky="ew", padx=2)
        self.app.save_scratch_btn = ttk.Button(parent, text="Save as JSON & Image", command=self.app.save_floorplan, state="disabled"); self.app.save_scratch_btn.pack(pady=5, fill=tk.X)
        self.app.scratch_door_controls = self.create_door_controls(parent)
        self.app.scratch_window_controls = self.create_window_controls(parent)