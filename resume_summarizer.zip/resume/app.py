import streamlit as st
import ollama
from pypdf import PdfReader
import os
import csv
import json
import re
import tempfile
import pandas as pd

# --- Config ---
OLLAMA_MODEL = "gemma3:latest"
CSV_OUTPUT = "resume_summary.csv"

def extract_text_from_pdf(pdf_file):
    """Extract text from a PDF file object"""
    reader = PdfReader(pdf_file)
    text = ""
    for page in reader.pages:
        text += page.extract_text() + "\n"
    return text.strip()

def analyze_resume_with_ollama(text, model=OLLAMA_MODEL):
    """Send extracted text to Ollama and get structured JSON-like output"""
    prompt = f"""
    Here is a resume text:

    {text}

    Please extract the following information and return in a structured JSON format:

    {{
      "Candidate Name": "...",
      "Contact Info": "...",
      "Education": "...",
      "Skills": "...",
      "Work Experience": "...",
      "Achievements": "...",
      "Summary": "..."
    }}
    """

    response = ollama.chat(
        model=model,
        messages=[{"role": "user", "content": prompt}]
    )
    return response["message"]["content"]

def parse_ollama_output(output_text, file_name):
    """Parse Ollama's JSON-like output safely into dict"""
    match = re.search(r"\{.*\}", output_text, re.DOTALL)
    parsed = {}
    if match:
        try:
            parsed = json.loads(match.group())
        except json.JSONDecodeError:
            parsed = {}

    return {
        "File Name": file_name,
        "Candidate Name": parsed.get("Candidate Name", ""),
        "Contact Info": parsed.get("Contact Info", ""),
        "Education": parsed.get("Education", ""),
        "Skills": parsed.get("Skills", ""),
        "Work Experience": parsed.get("Work Experience", ""),
        "Achievements": parsed.get("Achievements", ""),
        "Summary": parsed.get("Summary", output_text.strip())
    }

def save_to_csv(data_list, csv_file):
    """Save extracted resume data into a CSV file"""
    fieldnames = ["File Name", "Candidate Name", "Contact Info", "Education", "Skills", "Work Experience", "Achievements", "Summary"]

    file_exists = os.path.isfile(csv_file)

    with open(csv_file, mode="a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)

        if not file_exists:
            writer.writeheader()

        for data in data_list:
            writer.writerow(data)

# --- Streamlit UI ---
st.set_page_config(page_title="Resume Extractor", layout="wide")
st.title("📄 AI Resume Extractor")
st.write("Upload multiple resumes (PDFs), extract key info using Ollama, and save results to CSV.")

uploaded_files = st.file_uploader("Upload Resume PDFs", type=["pdf"], accept_multiple_files=True)

if uploaded_files:
    if st.button("Process Resumes"):
        results = []

        progress = st.progress(0)
        for idx, uploaded_file in enumerate(uploaded_files):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
                tmp_file.write(uploaded_file.read())
                tmp_file_path = tmp_file.name

            st.info(f"📄 Processing {uploaded_file.name}...")
            extracted_text = extract_text_from_pdf(tmp_file_path)
            ollama_output = analyze_resume_with_ollama(extracted_text)
            structured_data = parse_ollama_output(ollama_output, uploaded_file.name)
            results.append(structured_data)

            progress.progress((idx + 1) / len(uploaded_files))

        # Save results to CSV
        save_to_csv(results, CSV_OUTPUT)

        # Show results in table
        df = pd.DataFrame(results)
        st.success("✅ Resumes processed successfully!")
        st.dataframe(df)

        # Download CSV
        st.download_button(
            label="📥 Download CSV",
            data=df.to_csv(index=False).encode("utf-8"),
            file_name="resume_summary.csv",
            mime="text/csv"
        )
