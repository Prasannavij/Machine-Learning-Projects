# import ollama
# from pypdf import PdfReader
# import os
# import csv

# # --- Configuration ---
# PDF_FILE_PATH = "resume2.pdf"
# CSV_OUTPUT = "resume_summary.csv"
# OLLAMA_MODEL = "gemma3:latest"

# def extract_text_from_pdf(pdf_path):
#     """Extracts all text from a PDF file"""
#     reader = PdfReader(pdf_path)
#     text = ""
#     for page in reader.pages:
#         text += page.extract_text() + "\n"
#     return text.strip()

# def analyze_resume_with_ollama(text, model=OLLAMA_MODEL):
#     """Send extracted text to Ollama and get structured JSON-like output"""
#     prompt = f"""
#     Here is a resume text:

#     {text}

#     Please extract the following information and return in a structured JSON format:

#     {{
#       "Candidate Name": "...",
#       "Contact Info": "...",
#       "Education": "...",
#       "Skills": "...",
#       "Work Experience": "...",
#       "Achievements": "...",
#       "Summary": "..."
#     }}
#     """

#     response = ollama.chat(
#         model=model,
#         messages=[{"role": "user", "content": prompt}]
#     )
#     return response["message"]["content"]

# def save_to_csv(data, csv_file):
#     """Save extracted resume data into a CSV file"""
#     fieldnames = ["Candidate Name", "Contact Info", "Education", "Skills", "Work Experience", "Achievements", "Summary"]

#     # Create file if not exists
#     file_exists = os.path.isfile(csv_file)

#     with open(csv_file, mode="a", newline="", encoding="utf-8") as f:
#         writer = csv.DictWriter(f, fieldnames=fieldnames)

#         if not file_exists:
#             writer.writeheader()

#         writer.writerow(data)

# def parse_ollama_output(output_text):
#     """Parse Ollama's JSON-like output safely into dict"""
#     import json, re

#     # Extract JSON block from text (Ollama may add extra words)
#     match = re.search(r"\{.*\}", output_text, re.DOTALL)
#     if match:
#         try:
#             return json.loads(match.group())
#         except json.JSONDecodeError:
#             pass

#     # fallback if not valid JSON
#     return {
#         "Candidate Name": "",
#         "Contact Info": "",
#         "Education": "",
#         "Skills": "",
#         "Work Experience": "",
#         "Achievements": "",
#         "Summary": output_text.strip()
#     }

# def main():
#     if not os.path.exists(PDF_FILE_PATH):
#         print(f"❌ PDF file not found: {PDF_FILE_PATH}")
#         return
    
#     print("📄 Extracting text from resume...")
#     extracted_text = extract_text_from_pdf(PDF_FILE_PATH)

#     print("🤖 Sending extracted text to Ollama...")
#     ollama_output = analyze_resume_with_ollama(extracted_text, OLLAMA_MODEL)

#     print("📊 Parsing Ollama output...")
#     structured_data = parse_ollama_output(ollama_output)

#     print("💾 Saving to CSV...")
#     save_to_csv(structured_data, CSV_OUTPUT)

#     print(f"✅ Resume details saved in {CSV_OUTPUT}")

#     print("\n--- MAIN CONTENTS ---\n")
#     for key, value in structured_data.items():
#         print(f"{key}: {value}")

# if __name__ == "__main__":
#     main()


import ollama
from pypdf import PdfReader
import os
import csv
import json
import re

# --- Configuration ---
PDF_FOLDER = "resumes"   # put all your PDF resumes in this folder
CSV_OUTPUT = "resume_summary.csv"
OLLAMA_MODEL = "gemma3:latest"

def extract_text_from_pdf(pdf_path):
    """Extracts all text from a PDF file"""
    reader = PdfReader(pdf_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text() + "\n"
    return text.strip()

def analyze_resume_with_ollama(text, model=OLLAMA_MODEL):
    """Send extracted text to Ollama and get structured JSON-like output"""
    prompt = f"""
    Here is a resume text:

    {text}

    Please extract the following information and return in a structured JSON format:

    {{
      "Candidate Name": "...",
      "Contact Info": "...",
      "Education": "...",
      "Skills": "...",
      "Work Experience": "...",
      "Achievements": "...",
      "Summary": "..."
    }}
    """

    response = ollama.chat(
        model=model,
        messages=[{"role": "user", "content": prompt}]
    )
    return response["message"]["content"]

def save_to_csv(data, csv_file):
    """Save extracted resume data into a CSV file"""
    fieldnames = ["File Name", "Candidate Name", "Contact Info", "Education", "Skills", "Work Experience", "Achievements", "Summary"]

    # Create file if not exists
    file_exists = os.path.isfile(csv_file)

    with open(csv_file, mode="a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)

        if not file_exists:
            writer.writeheader()

        writer.writerow(data)

def parse_ollama_output(output_text, file_name):
    """Parse Ollama's JSON-like output safely into dict"""
    match = re.search(r"\{.*\}", output_text, re.DOTALL)
    parsed = {}
    if match:
        try:
            parsed = json.loads(match.group())
        except json.JSONDecodeError:
            parsed = {}

    # fallback if missing fields
    return {
        "File Name": file_name,
        "Candidate Name": parsed.get("Candidate Name", ""),
        "Contact Info": parsed.get("Contact Info", ""),
        "Education": parsed.get("Education", ""),
        "Skills": parsed.get("Skills", ""),
        "Work Experience": parsed.get("Work Experience", ""),
        "Achievements": parsed.get("Achievements", ""),
        "Summary": parsed.get("Summary", output_text.strip())
    }

def main():
    if not os.path.exists(PDF_FOLDER):
        print(f"❌ Folder not found: {PDF_FOLDER}")
        return

    pdf_files = [f for f in os.listdir(PDF_FOLDER) if f.lower().endswith(".pdf")]
    if not pdf_files:
        print("❌ No PDF files found in the folder.")
        return

    print(f"📂 Found {len(pdf_files)} PDFs. Processing...\n")

    for pdf_file in pdf_files:
        pdf_path = os.path.join(PDF_FOLDER, pdf_file)

        print(f"📄 Extracting text from: {pdf_file}")
        extracted_text = extract_text_from_pdf(pdf_path)

        print(f"🤖 Sending {pdf_file} to Ollama...")
        ollama_output = analyze_resume_with_ollama(extracted_text, OLLAMA_MODEL)

        print(f"📊 Parsing Ollama output for {pdf_file}...")
        structured_data = parse_ollama_output(ollama_output, pdf_file)

        print(f"💾 Saving {pdf_file} to CSV...")
        save_to_csv(structured_data, CSV_OUTPUT)

        print(f"✅ {pdf_file} processed!\n")

    print(f"🎉 All resumes processed! Data saved in {CSV_OUTPUT}")

if __name__ == "__main__":
    main()
