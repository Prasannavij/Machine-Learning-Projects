API_KEY = 'AIzaSyBVS1Mlw-YJU5IgfuAG1oLizhnpibcZ0Mg'
MODEL_NAME = 'gemini-1.5-flash'
