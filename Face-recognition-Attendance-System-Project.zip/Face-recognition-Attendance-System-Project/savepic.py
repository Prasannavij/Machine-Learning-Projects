import cv2
import os
import time

# Set the person's name for labeling the images
person_name = "Prasanna_Vijayakumar"  # Change this to your name
output_folder = f"Dataset/{person_name}"  # Folder where images will be stored

# Create folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Start webcam
cap = cv2.VideoCapture(0)
time.sleep(2)  # Wait for the camera to adjust

# Capture 500 images
total_images = 500  
capture_interval = 0.2  # Capture image every 0.2 seconds

image_count = 0  # Counter for captured images

print(f"🔹 Capturing {total_images} images. Please stay in front of the camera.")

while image_count < total_images:
    success, frame = cap.read()
    if not success:
        break

    # Save image with a unique filename (1 to 500)
    img_number = image_count + 1
    img_path = os.path.join(output_folder, f"{person_name}_{img_number}.jpg")
    cv2.imwrite(img_path, frame)
    
    # Display the live capture
    cv2.putText(frame, f"Capturing: {img_number}/{total_images}", (50, 50), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.imshow("Capturing Images", frame)

    image_count += 1
    time.sleep(capture_interval)  # Wait before capturing the next image

    # Press 'q' to exit early
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
print(f"✅ Captured {image_count} images from 1 to {image_count} in '{output_folder}'")
