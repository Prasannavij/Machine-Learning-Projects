import requests

# Function to fetch exercise info from ExerciseDB API
def get_exercise_info(exercise_name):
    # API endpoint for exercise search by name
    api_url = f"https://exercisedb.p.rapidapi.com/exercises/name/{exercise_name}"

    # Headers for the API request
    headers = {
        "X-RapidAPI-Key": "ba0ea723b7msh4e41786badc4dfcp1390d6jsn67a709b8a188",  # Get this from RapidAPI after signing up
        "X-RapidAPI-Host": "exercisedb.p.rapidapi.com"
    }

    # Make the GET request to fetch the exercise data
    response = requests.get(api_url, headers=headers)
    
    # Check if the request was successful
    if response.status_code == 200:
        exercise_data = response.json()
        if exercise_data:
            # Print exercise details
            print(f"Exercise: {exercise_data[0]['name']}")
            print(f"Target Muscle: {exercise_data[0]['target']}")
            print(f"Equipment: {exercise_data[0]['equipment']}")
            print(f"Body Part: {exercise_data[0]['bodyPart']}")
        else:
            print("No exercise found.")
    else:
        print(f"Failed to fetch exercise info. Status code: {response.status_code}")

# Main execution
if __name__ == "__main__":
    exercise = input("Enter the name of the exercise: ").lower()
    get_exercise_info(exercise)
