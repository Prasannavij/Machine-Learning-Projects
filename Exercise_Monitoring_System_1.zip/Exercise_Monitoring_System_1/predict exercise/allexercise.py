import requests

# Function to fetch all exercises from the ExerciseDB API
def get_all_exercises():
    # API endpoint for fetching all exercises
    api_url = "https://exercisedb.p.rapidapi.com/exercises"

    # Headers with your RapidAPI key
    headers = {
        "X-RapidAPI-Key": "ba0ea723b7msh4e41786badc4dfcp1390d6jsn67a709b8a188",  # Replace with your API key
        "X-RapidAPI-Host": "exercisedb.p.rapidapi.com"
    }

    # Make the GET request to fetch all exercises
    response = requests.get(api_url, headers=headers)

    # Check if the request was successful
    if response.status_code == 200:
        exercise_data = response.json()
        # Loop through the data and print exercise names
        for exercise in exercise_data:
            print(exercise['name'])
    else:
        print(f"Failed to fetch exercises. Status code: {response.status_code}")

# Main execution
if __name__ == "__main__":
    get_all_exercises()
