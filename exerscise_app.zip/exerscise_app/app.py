from flask import Flask, send_from_directory, request, jsonify, render_template_string, session, redirect
import os
import subprocess
import requests
import google.generativeai as genai

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Get the absolute path of the current directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

@app.route('/')
def home():
    with open(os.path.join(BASE_DIR, 'Frontend', 'index.html'), 'r') as file:
        html_content = file.read()
    return render_template_string(html_content)

# Serve static files like CSS and GIF
@app.route('/Frontend/<path:filename>')
def serve_static(filename):
    return send_from_directory(os.path.join(BASE_DIR, 'Frontend'), filename)

# Function to fetch exercise info from ExerciseDB API
def get_exercise_info_exercisedb(exercise_name):
    api_url = f"https://exercisedb.p.rapidapi.com/exercises/name/{exercise_name}"
    headers = {
        "X-RapidAPI-Key": "ba0ea723b7msh4e41786badc4dfcp1390d6jsn67a709b8a188",
        "X-RapidAPI-Host": "exercisedb.p.rapidapi.com"
    }
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        exercise_data = response.json()
        if exercise_data:
            return {
                "exercise": exercise_data[0]['name'],
                "target_muscle": exercise_data[0]['target'],
                "equipment": exercise_data[0]['equipment'],
                "body_part": exercise_data[0]['bodyPart']
            }
    return None

# Route to start monitoring script
@app.route('/start_monitoring', methods=['POST'])
def start_monitoring():
    try:
        subprocess.run(["python", "Exercise_monitoring.py"], check=True)
        return jsonify({"status": "Exercise Monitoring completed! Check terminal for output."})
    except subprocess.CalledProcessError as e:
        return jsonify({"error": f"Monitoring script failed: {str(e)}"})
    except Exception as e:
        return jsonify({"error": str(e)})


# Class for Gemini API Integration
class GeminiAPI:
    def __init__(self, api_key):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')

    def get_exercise_info(self, exercise_name):
        prompt = f"Provide detailed insights on the exercise '{exercise_name}', including its benefits, target muscles, and correct form."
        try:
            response = self.model.generate_content([prompt])
            if hasattr(response, 'text'):
                return response.text.replace("\n", "<br>")
        except Exception:
            return None

# Function to fetch exercise image from Pexels API
def get_exercise_image(exercise_name):
    api_url = f"https://api.pexels.com/v1/search?query={exercise_name}&per_page=1"
    headers = {
        "Authorization": "5D2aj19KjNmc7wRg9hytlRjABdJAfFABWkbUHyHYqn0sPgwBgmVt3JYb"
    }
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        image_data = response.json()
        if image_data['photos']:
            return image_data['photos'][0]['src']['original']
    return None

# Function to fetch a YouTube tutorial video using YouTube Data API v3
def get_youtube_video(exercise_name):
    youtube_api_key = "AIzaSyAKG2YIGb_WrYovaH2D3MhA6IG39AMDqhE"
    search_url = "https://www.googleapis.com/youtube/v3/search"
    params = {
        "part": "snippet",
        "q": f"{exercise_name} workout tutorial",
        "key": youtube_api_key,
        "maxResults": 1,
        "type": "video"
    }
    response = requests.get(search_url, params=params)
    if response.status_code == 200:
        search_results = response.json()
        if search_results.get("items"):
            video_id = search_results["items"][0]["id"]["videoId"]
            return f"https://www.youtube.com/watch?v={video_id}"
    return None

@app.route('/exercise_info', methods=['GET'])
def exercise_info():
    exercise_name = request.args.get("name", "").strip().lower()
    if not exercise_name:
        return jsonify({"error": "Please provide an exercise name."})

    gemini_api_key = "AIzaSyDWdua6jPuK5lwqfvCuopjpd16cyWQBan0"
    gemini_api = GeminiAPI(gemini_api_key)
    exercise_data = get_exercise_info_exercisedb(exercise_name)
    gemini_info = gemini_api.get_exercise_info(exercise_name)
    exercise_image = get_exercise_image(exercise_name)
    youtube_video = get_youtube_video(exercise_name)

    if not exercise_data and not gemini_info:
        return jsonify({"error": "Exercise not found in all APIs."})

    session['exercise_data'] = "<div style='text-align:left; font-family:Arial, sans-serif; font-size:16px;'>"

    if exercise_data:
        session['exercise_data'] += f"""
            <b>📌 Exercise:</b> {exercise_data['exercise']}<br>
            <b>💪 Target Muscle:</b> {exercise_data['target_muscle']}<br>
            <b>🏋️ Equipment:</b> {exercise_data['equipment']}<br>
            <b>🦵 Body Part:</b> {exercise_data['body_part']}<br>
        """
    
    if gemini_info:
        session['exercise_data'] += f"<b>📝 Gemini AI Insights:</b><br>{gemini_info}<br>"
    
    if exercise_image:
        session['exercise_data'] += f"<b>🖼️ Exercise Image:</b><br><img src='{exercise_image}' alt='Exercise Image' width='300'><br>"
    
    if youtube_video:
        session['exercise_data'] += f"<b>🎥 YouTube Tutorial:</b> <a href='{youtube_video}' target='_blank'>Watch Here</a><br>"
    
    session['exercise_data'] += "</div><br><button onclick=\"window.location='/maximize_output'\" style='padding:10px; background:#ff6b6b; color:white; border:none; cursor:pointer;'>🔍 Maximize</button>"
    
    return session['exercise_data']

@app.route('/get_exercise_data')
def get_exercise_data():
    return session.get('exercise_data', '<b>No exercise data available.</b>')

@app.route('/maximize_output')
def maximize_output():
    return send_from_directory(os.path.join(BASE_DIR, 'Frontend'), 'maximize_result.html')

if __name__ == '__main__':
    app.run(debug=True)