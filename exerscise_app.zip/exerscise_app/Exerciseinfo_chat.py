import requests
import google.generativeai as genai

# Function to fetch exercise info from ExerciseDB API
def get_exercise_info_exercisedb(exercise_name):
    api_url = f"https://exercisedb.p.rapidapi.com/exercises/name/{exercise_name}"
    headers = {
        "X-RapidAPI-Key": "ba0ea723b7msh4e41786badc4dfcp1390d6jsn67a709b8a188",  # Replace with your actual RapidAPI key
        "X-RapidAPI-Host": "exercisedb.p.rapidapi.com"
    }
    response = requests.get(api_url, headers=headers)

    if response.status_code == 200:
        exercise_data = response.json()
        if exercise_data:
            return {
                'source': 'ExerciseDB',
                'exercise': exercise_data[0]['name'],
                'target_muscle': exercise_data[0]['target'],
                'equipment': exercise_data[0]['equipment'],
                'body_part': exercise_data[0]['bodyPart']
            }
    return None

# Class for Gemini API Integration
class GeminiAPI:
    def __init__(self, api_key):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')

    def get_exercise_info(self, exercise_name):
        prompt = (f"Provide detailed information about the exercise '{exercise_name}'. "
                  "Include target muscles, equipment used, and body parts worked.")
        
        try:
            response = self.model.generate_content([prompt])
            if hasattr(response, 'text'):
                return {'source': 'GeminiAPI', 'text': response.text}
        except Exception as e:
            return None

# Function to fetch exercise image from Pexels API
def get_exercise_image(exercise_name):
    api_url = f"https://api.pexels.com/v1/search?query={exercise_name}&per_page=1"
    headers = {
        "Authorization": "5D2aj19KjNmc7wRg9hytlRjABdJAfFABWkbUHyHYqn0sPgwBgmVt3JYb"  # Replace with your actual Pexels API key
    }
    response = requests.get(api_url, headers=headers)

    if response.status_code == 200:
        image_data = response.json()
        if image_data['photos']:
            return image_data['photos'][0]['src']['original']  # Returns the direct image URL
    return None

# ✅ Function to fetch a YouTube tutorial video using YouTube Data API v3
def get_youtube_video(exercise_name):
    youtube_api_key = "AIzaSyAKG2YIGb_WrYovaH2D3MhA6IG39AMDqhE"  # Replace with your actual YouTube API key
    search_url = "https://www.googleapis.com/youtube/v3/search"

    params = {
        "part": "snippet",
        "q": f"{exercise_name} workout tutorial",
        "key": youtube_api_key,
        "maxResults": 1,  # Get the top result
        "type": "video"
    }

    response = requests.get(search_url, params=params)
    
    if response.status_code == 200:
        search_results = response.json()
        if search_results.get("items"):
            video_id = search_results["items"][0]["id"]["videoId"]
            return f"https://www.youtube.com/watch?v={video_id}"  # Construct YouTube video link
    return None

# Main execution
if __name__ == "__main__":
    gemini_api_key = "AIzaSyDWdua6jPuK5lwqfvCuopjpd16cyWQBan0"  # Replace with your actual Gemini API key
    gemini_api = GeminiAPI(gemini_api_key)

    exercise_name = input("Enter the name of the exercise: ").strip().lower()

    exercise_info_exercisedb = get_exercise_info_exercisedb(exercise_name)
    exercise_info_gemini = gemini_api.get_exercise_info(exercise_name)
    exercise_image_url = get_exercise_image(exercise_name)
    youtube_video_url = get_youtube_video(exercise_name)  # ✅ Uses YouTube API v3

    # Display ExerciseDB API results
    if exercise_info_exercisedb:
        print(f"\nExercise Information from ExerciseDB API:")
        print(f"Exercise: {exercise_info_exercisedb['exercise']}")
        print(f"Target Muscle: {exercise_info_exercisedb['target_muscle']}")
        print(f"Equipment: {exercise_info_exercisedb['equipment']}")
        print(f"Body Part: {exercise_info_exercisedb['body_part']}")

    # Display Gemini API results
    if exercise_info_gemini:
        print(f"\nExercise Information from Gemini API:")
        print(exercise_info_gemini['text'])

    # Display Exercise Image
    if exercise_image_url:
        print(f"\nExercise Image: {exercise_image_url}")

    # ✅ Display YouTube Video Recommendation (Using YouTube API v3)
    if youtube_video_url:
        print(f"\nRecommended YouTube Video: {youtube_video_url}")

    # If no information is found
    if not exercise_info_exercisedb and not exercise_info_gemini and not youtube_video_url:
        print("\nExercise not found in all APIs.")
